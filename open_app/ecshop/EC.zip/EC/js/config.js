var ourl = "192.168.1.208/ecshop/";
//var ourl = "www.zg2020.com/";
//var ourl = "www.itpat.com/";
//var ourl = "www.fashionwholesale.com.my/fw-app/";
//var ourl = "www.51tt.com.cn/";
//var ourl = "www.xhm8.com:9090/";
var url_ = "http://"+ourl;
var httpUrl = url_ + "plugins/zywx/rpc/";
var image_url = url_;


/*var ourl = "discuz.3g2win.com//";
var url_ = "http://"+ourl;
var httpUrl = url_ + "plugins/zywx/rpc/";
var image_url = url_;*/
