/*myJs*/
/*var url_com = "http://te.3g2win.com/wordpress/"; 
//var url_com = "http://192.168.1.208/wordpress/";
var httpUrl = url_com + "?callback=?";

var serverurl=url_com;
var url_end ="?callback=?";

var showtime_url=serverurl+url_end+"&zywxapp/content/list/products&limit=3";
var showtime_detail_url=serverurl+url_end+"&zywxapp/content/product/";

var bound_number_url=serverurl+url_end+"&zywxapp/user/login/";
var my_profile_url=serverurl+url_end+"&zywxapp/content/user/";
var edit_url=serverurl+url_end+"&zywxapp/user/edit/";
var exit_url=serverurl+url_end+"&zywxapp/user/logout/";
var search_url=serverurl+url_end+"&zywxapp/search&keyword=";
var class_url=serverurl+url_end+"&zywxapp/content/list/categories&limit=2";
var label_url=serverurl+url_end+"&zywxapp/content/list/tags&limit=5";

function getFirstArticleUrl(type,num){
	return httpUrl + "&zywxapp/content/list/posts/&type="+type+"&limit="+num;
}
function getNextArticleUrl(type,lid,num){
	return httpUrl + "&zywxapp/content/list/posts/&type="+type+"&down="+lid+"&limit="+num;
}
function getPreArticleUrl(type,lid,num){
	return httpUrl + "&zywxapp/content/list/posts/&type="+type+"&up="+lid+"&limit="+num;
}*/

function $toast(){
	uexWindow.toast('1', '5', '加载中...', '0');
}
function $closeToast(){
	uexWindow.closeToast();
}
function readLocFile(rid,path,size){
	uexFileMgr.openFile(rid,path,'1');
	uexFileMgr.readFile(rid,size);
	uexFileMgr.closeFile(rid);
}
function writeFile(wid,path,data){
	uexFileMgr.openFile(wid,path,'1');
	uexFileMgr.writeFile(wid,'0',data);
	uexFileMgr.closeFile(wid);
}
function xmlHttp(rid,url){
	uexWindow.toast('1', '5', '加载中..', '0');
	uexXmlHttpMgr.open(rid, "GET", url,"60000");
	uexXmlHttpMgr.send(rid);
}
function createFile(cid,path){
	uexFileMgr.createFile(cid,path);
	uexFileMgr.closeFile(cid);
}

function $alert(mes){
	uexWindow.alert("提示",mes,"确定");
}

function $jsonStr(result){
	var res = '';
	if(result.indexOf("?(") == 0){
		res = (result.substr(result.indexOf("?(")+2,result.length)).substr(0,result.length-3);
	}else if(result.indexOf("({") == 0){
		res = (result.substr(result.indexOf("?(")+1,result.length)).substr(0,result.length-2);
	}else{
		res = result;
	}		
	return res;
}
function $id(id){
	return document.getElementById(id);
}
function $getTime(dateStr){
	var oldDate = new Date(dateStr);
	var oldTime = oldDate.getTime();
	var nowDate = new Date();
	var nowTime = nowDate.getTime();
	var chaZhi = nowTime - oldTime;
	chaZhi = chaZhi/1000;
	if(chaZhi > 0){
		var mf = Math.ceil((chaZhi/60));
		if(mf < 1) return "刚刚";
		if(mf < 60){
			return mf+"分钟前";
		}else if(mf > 60){
			var hf = Math.ceil(mf/60);
			if(hf>=1 && hf < 24){
				return hf + "小时前";
			}else{
				if(oldDate.getFullYear() == nowDate.getFullYear() && oldDate.getMonth() == nowDate.getMonth() && oldDate.getDate() == nowDate.getDate()){
					return "今天 "+oldDate.getHours()+":"+oldDate.getMinutes()+":"+oldDate.getSeconds();
				}else{
					return  oldDate.getFullYear()+"-"+(oldDate.getMonth()+1)+"-"+oldDate.getDate();
				}
			}
		}
	}else{
		return  oldDate.getFullYear()+"-"+(oldDate.getMonth()+1)+"-"+oldDate.getDate();
	}
}

function $timeLine(dateStr){
	return $getTime(dateStr);
	/*var oldDate = new Date(dateStr);
	var oldTime = oldDate.getTime();
	var nowDate = new Date();
	var nowTime = nowDate.getTime();
	var chaZhi = nowTime - oldTime;
	var mf = Math.floor((chaZhi/60));
	if(mf < 0) return dateStr;
	if(mf < 60) return mf + "鍒嗛挓鍓�;
	var hf =Math.floor(mf/60);
	if(hf < 24){
		if(oldDate.getFullYear() == nowDate.getFullYear() && oldDate.getMonth() == nowDate.getMonth() && oldDate.getDate() == nowDate.getDate()){
			return hf + "灏忔椂鍓�;
		}else{
			return "1澶╁墠";
		}
	}

	
	var chaDay = hf/24;
	if(chaDay < 7) return chaDay + "澶╁墠";
	return oldDate.getFullYear()+"-"+(oldDate.getMonth()+1)+"-"+oldDate.getDate();;*/
}
var openUrl_arr = new Array();
var intval = 0;
function showDeatil(dataObj){
	openUrl_arr = [];
	var allStr = '<div style="margin:0.5em;" class="ui-box-item ui-box-flex2" id="allDivId"><div class="ui-smaller">';
	$id("text_commeng_id").innerHTML = dataObj.comment_count;
	var titleStr = dataObj.title.length > 10 ?  dataObj.title.substr(0,10)+"..." : dataObj.title;
	$id("h_title_id").innerHTML = titleStr;
	$id("h_date_id").innerHTML  =  $getTime(dataObj.date);
	if(dataObj.zone_time != null || dataObj.travel_time){
		var nstr = '';
		if(dataObj.zone_time != null) nstr += dataObj.zone_time;
		if(dataObj.travel_time != null) nstr += '&nbsp;&nbsp;'+ dataObj.travel_time;
		allStr += '<div class="ui-loc-cen ui-font-size-title" style="border-bottom:1px solid #ccc;">'+nstr+'</div>';
	}
	allStr += "&nbsp;&nbsp;&nbsp;&nbsp;"+dataObj.content;
	if(dataObj.address != null){
		allStr += '<br/><br/>'+dataObj.address+'<div class="ui-box">地图:div onclick="openNewMap(\''+dataObj.longitude+'\',\''+dataObj.latitude+'\')" class="ui-loc-flag"></div></div>';
	}
	allStr += '</div></div>';
	var attachments = dataObj.attachments;
	var len = attachments.length;
	var textType = '';
	if(len > 0){
		var scrollStr = '<div class="ui-box-item ui-box-flex1 ui-box"><div id="img_change_id" class="ui-box-item ui-box-content ui-box ui-box-hor">';
		var pointStr = '<div style="min-height:1em; height:2%; color: white;text-shadow: 0 1px 0 white;"><ul class="w_order" id="point_id">';
		var imageUrl_ = '';
		for(var i = 0; i < len; i++){
			var detailObj = attachments[i];
			var atype = detailObj.attachment_type;			
			textType = atype;
			switch(atype){
				case '':
					imageUrl_ = "<div></div>"
					break;
				case 'video':
					openUrl_arr.push(detailObj.attachment_url);
					imageUrl_ = '<div class="ui-box-content ui-box-img" style="background-image:url(images/video.png)"></div>';
					break;
				case 'audio':
					openUrl_arr.push(detailObj.attachment_url);
					imageUrl_ = '<div class="ui-box-content ui-box-img" style="background-image:url(images/music.png)"></div>';
					break;
				case 'image':
					openUrl_arr.push(detailObj.attachment_url);
					var tr = '';
					if(i==0)
						tr = '<input type="radio" class="ui-hide" name="imgTextlist" checked="true">';
					else
						tr = '<input type="radio" class="ui-hide" name="imgTextlist">';
				//	var aurl = httpUrl + '&zywxapp/getimage/&width=100&url='+detailObj.attachment_url;
				//	imageUrl_ += tr+'<div class="ui-box-content ui-box-img ui-imgText-anim ui-imgText" style="background-image:url('+aurl+')"></div>';
					imageUrl_ += tr+'<div class="ui-box-content ui-box-img ui-imgText-anim ui-imgText" style="background-image:url('+detailObj.attachment_url+')"></div>';
					break;
				default:break;
			}
		}
		scrollStr += '<div id="textImageId" class="ui-box-item ui-box-flip-hor ui-box"></div>'		
		scrollStr += '</div></div>';
		pointStr += '</ul><div class="clear"></div></div><div style="min-height:2em; "></div>';
		allStr += scrollStr;
	//	allStr += pointStr;
	}else{
		allStr += '<div style="min-height:2em; "></div>';
	}
	$id("allTextId").innerHTML = allStr;
	var s1= new iScroll("allDivId");
	$id("textImageId").innerHTML = imageUrl_;
	if(textType == "video"){
		$id("textImageId").setAttribute("onclick","openVideo()");
	}else if(textType == "audio"){
		$id("textImageId").setAttribute("onclick","openMusic()");
	}else if(textType == "image"){
		$id("textImageId").setAttribute("onclick","showImage()");
		intval = setInterval('chagnePoint_()',3000);
	}
}
function showImage(){
	uexImageBrowser.open(openUrl_arr);
}
function openMusic(){
	uexAudio.openPlayer(openUrl_arr);
}
function openVideo(){
	uexVideo.open(openUrl_arr[0]);
}
var mycon_ = 0;
function chagnePoint_(){
	var list=$id("textImageId").getElementsByTagName('input');
	var index=(mycon_%list.length);
	list[index].checked=true;
	mycon_++;
}
function clearInt(){
	clearInterval(intval);
}

var updateUrl = '';
var app_name = "";
var saveUpdate = "";
function checkUpdate(){
	 uexWidgetOne.cbGetPlatform = function(opId,dataType,data){		
		if(data==0){ //iphone
		    //uexWindow.alert("更新地址：",updateUrl,"确定");
			//uexDownloaderMgr.createDownloader('100');
			uexWidget.loadApp(updateUrl,"",updateUrl);
		}else if(data==1){ //android
			saveUpdate = "/sdcard/download/wordpress.apk";
			uexDownloaderMgr.createDownloader('100');
		}
	}

    uexWindow.cbConfirm = function ConfirmSuccess(opId, dataType, data){
        if (data == 1) {
          uexWidgetOne.getPlatform();
        }
    }
    /*update callback*/
    uexWidget.cbCheckUpdate = function(opCode, dataType, jsonData){
		
        var obj = eval('(' + jsonData + ')');
        if (obj.result == 0) {
			updateUrl = obj.url;
			//app_name = obj.name;
            var value = "稍后;更新";
            var mycars = value.split(";");
            uexWindow.confirm('', '当前有新版本，是否更新?', mycars);
        }else if (obj.result == 1) {
                ;//tips = "当前版本是最新的";alert(tips);
        }else if (obj.result == 2) {
            ;//tips = "未知错误";alert(tips);
        }else if (obj.result == 3) {
	        ;//tips = "参数错误";alert(tips);
        }
    }
    uexWidget.checkUpdate();
}
