function log(s)
 {
 	uexLog.sendLog(s);
 }

function dis_slectmenu(id, cb) {
	var sl = document.getElementById(id);
	if (sl) {
		var sp = sl.parentElement; // <span>
		if (sp) {
			var ch = sp.getElementsByTagName("span")[0];
			var ch = ch.getElementsByTagName("span")[0];
			var t = sl.options[sl.selectedIndex].text;
			if (ch) {
				ch.innerHTML = t;
			}

			if (cb) {
				
				cb(sl.selectedIndex);
			}
			
		}
	}
}


function $$(id) {
	if (id != null) {
		return document.getElementById(id);
	}
	return null;
}
/*
 * todo set htmlele for element by id example setHtml("id", "<a>value</a>");
 */
function setHtml(id, html) {
	if ("string" == typeof(id)) {
		var ele = $$(id);
		if (ele != null) {
			ele.innerHTML = html == null ? "" : html;
		}
	} else if (id != null) {
		id.innerHTML = html == null ? "" : html;
	}
}
/**
 * 鍒ゆ柇鍙傛暟鏄惁瀹氫箟
 * 
 * @author LLX
 * @param para
 *            return boolean
 */

function isDefine(para) {
	if (typeof para == 'undefined' || para == "" || para == null
			|| para == 'undefined') {
		return false;
	} else {
		return true;
	}
}

// 判断变量是否定义
function isUndefined(variable) {
	return typeof variable == 'undefined' ? true : false;
}

function getValue(id) {
	return getAttrById(id, "value");
}
function setValue(id, value) {
	setAttrById(id, "value", value)
}

function getAttrById(id, name) {
	if ("string" == typeof(id)) {
		var ele = $$(id);
		if (ele != null) {
			if (name != null) {
				var tmp = ele[name];
				if (tmp != null) {
					return tmp;
				}
			}
		}
	} else {
		if (id != null) {
			return id[name];
		}
	}
	return null;
}
function setAttrById(id, name, value) {
	if ("string" == typeof(id)) {
		var ele = $$(id);
		if (ele != null) {
			if (name != null) {
				ele[name] = value;
			}
		}
	} else {
		if (id != null && name != null) {
			id[name] = value;
		}
	}
}

function trim(s) {
	var count = s.length;
	var st = 0; // start
	var end = count - 1; // end

	if (s == "")
		return s;
	while (st < count) {
		if (s.charAt(st) == " ")
			st++;
		else
			break;
	}
	while (end > st) {
		if (s.charAt(end) == " ")
			end--;
		else
			break;
	}
	return s.substring(st, end + 1);
}
function fucCheckLength(strTemp) {
	var i, sum;
	sum = 0;
	for (i = 0; i < strTemp.length; i++) {
		if ((strTemp.charCodeAt(i) >= 0) && (strTemp.charCodeAt(i) <= 255))
			sum = sum + 1;
		else
			sum = sum + 2;
	}
	return sum;
}

var prImgSrc = '../images/loading.gif';
//判断是否加载完成
function Imagess(url,imgid,callback,cmd){
	if(cmd)
		prImgSrc = 'images/loading.gif';
    var val=url;
	var img=new Image();
	//如果因为网络或图片的原因发生异常，则显示该图片
    img.onerror=function(){img.src=prImgSrc;};
    img.src=val;
	if (img.complete) {
		callback(img,imgid);
	} else {
		img.onload = function () {
			callback(img,imgid);
			img.onload = null;
		}
	}
  
}

//显示图片
function checkimg(obj,imgid){
	$$(imgid).src=obj.src;
}

function openwin(winName,url,anim){
	uexWindow.open(winName, "0",url,anim,"","",4);
}
function openNavWindow(winName,url,anim){
	uexWindow.open(winName, "0",url,anim,"","",0);
}
 
 function setfootstyle(flag, index, footid){
 	var str = new Array('', '', '', '', '');
 	var txt = new Array('ui-block-b', 'ui-block-c', 'ui-block-d', 'ui-block-e');
 	var grid = '<ul class="ui-grid-d">';
 	var laststr = '';
 	var img = 'images/icon_new.png';
 	if(index==3 || index==5) img = '../'+img;
 	if(flag==0) //flag=1：底部有5项菜单，flag=0：有4项。
 	{
 		txt[3] = txt[2];
 		txt[2] = txt[1];
 		txt[1] = txt[0];
 		grid = '<ul class="ui-grid-c">';
 	}
 	str[index] = 'checked = "checked"';
 	if(flag==1) laststr = '<li class="'+txt[0]+'"><input type="radio" '+str[2]+' name="radiof1" id="radio-f1b" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(2);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-portal"></span><span class="ui-btn-inner"><span class="ui-btn-text">资讯</span></span></label></li>';
 	var res = '<div class="ui-navbar  ui-nav-iphone ui-foot-glass">'+grid+'<li class="ui-block-a"><input type="radio" '+str[1]+' name="radiof1" id="radio-f1a" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(1);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-forum"></span><span class="ui-btn-inner"><span class="ui-btn-text">论坛</span></span></label></li>'+laststr+'<li class="'+txt[1]+'"><input type="radio" '+str[3]+' name="radiof1" id="radio-f1c" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(3);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-msg" ></span><img src="'+img+'" class="dis_display_none" style="position: absolute; width:1.5em; height:1.5em; right:0.6em; top:.1em;" id="icon_msg"><span class="ui-btn-inner"><span class="ui-btn-text">消息</span></span></label></li><li class="'+txt[2]+'"><input type="radio" '+str[4]+' name="radiof1" id="radio-f1d" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(4);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-friend"></span><span class="ui-btn-inner"><span class="ui-btn-text">找朋友</span></span></label></li><li class="'+txt[3]+'"><input type="radio" '+str[5]+' name="radiof1" id="radio-f1e" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(5);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-more"></span><img src="'+img+'" class="dis_display_none" style="position: absolute; width:1.5em; height:1.5em; right:0.6em; top:.1em;" id="icon_more"><span class="ui-btn-inner"><span class="ui-btn-text">更多</span></span></label></li></ul></div>';
 	setHtml(footid,res);
 }
 
 function setmenu(flag){
 	if(flag == 0){//没有删除功能
 		var str = '<div class="ui-navbar  ui-nav-iphone ui-bar-glass ui-nav-dis"><ul class="ui-grid-b"><li class="ui-block-a"><input type="radio"  name="radiof1" id="radio-f1a" class="ui-hide"><label onclick="zy_for(event);uexWindow.evaluateScript(\'\',\'0\',\'comment_add();\')" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-comment"></span><span class="ui-btn-inner"><span class="ui-btn-text">回复</span></span></label></li><li class="ui-block-b"><input type="radio" name="radiof1" id="radio-f1b" class="ui-hide"><label onclick="zy_for(event);uexWindow.evaluateScript(\'\',\'0\',\'favorite();\')" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-favorite"></span><span class="ui-btn-inner"><span class="ui-btn-text"id="favor">收藏</span></span></label></li><li class="ui-block-c"><input type="radio" name="radiof1" id="radio-f1c" class="ui-hide"><label onclick="zy_for(event);uexWindow.evaluateScript(\'\',\'0\',\'share();\')" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-share"></span><span class="ui-btn-inner"><span class="ui-btn-text">分享</span></span></label></li></ul></div>';
	 }else{
	 		var str = '<div class="ui-navbar  ui-nav-iphone ui-bar-glass ui-nav-dis"><ul class="ui-grid-c"><li class="ui-block-a"><input type="radio" name="radiof1" id="radio-f1a" class="ui-hide"><label onclick="zy_for(event);uexWindow.evaluateScript(\'\',\'0\',\'comment_add();\')" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-comment"></span><span class="ui-btn-inner"><span class="ui-btn-text">回复</span></span></label></li><li class="ui-block-b"><input type="radio" name="radiof1" id="radio-f1b" class="ui-hide"><label onclick="zy_for(event);uexWindow.evaluateScript(\'\',\'0\',\'favorite();\')" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-favorite"></span><span class="ui-btn-inner"><span class="ui-btn-text"id="favor">收藏</span></span></label></li><li class="ui-block-c"><input type="radio" name="radiof1" id="radio-f1c" class="ui-hide"><label onclick="zy_for(event);uexWindow.evaluateScript(\'\',\'0\',\'share();\')" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-share"></span><span class="ui-btn-inner"><span class="ui-btn-text">分享</span></span></label></li><li class="ui-block-d"><input type="radio" name="radiof1" id="radio-f1c" class="ui-hide"><label onclick="zy_for(event);uexWindow.evaluateScript(\'\',\'0\',\'deleteopt();\')" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-delete"></span><span class="ui-btn-inner"><span class="ui-btn-text">删除</span></span></label></li></ul></div>';
	 }
	 setHtml("navmenuBar",str);
 }
 
function setDisplayBlock(id)
{
	var ele = $$(id);
	if(ele) ele.className = "dis_display_block";
}
function setDisplayNone(id)
{
	var ele = $$(id);
	if(ele) ele.className = "dis_display_none";
}
 
//查看图片
function viewimage(e){
	var array=new Array();
	array[0] = e.src;
	uexImageBrowser.open(array);
}

function setfootstyle_simple(index, footid){
 	var str = new Array('', '', '', '','');
 	var choice_color = new Array('', '', '', '','');
 	str[index] = 'checked = "checked"';
 	choice_color[index] = ' nav-choice-color-s ';
 	var res = '<div class="ui-navbar  ui-nav-iphone ui-bar-glass"><ul class="ui-grid-c"><li class="ui-block-a"><input type="radio" '+str[1]+' name="radiof1" id="radio-f1a" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(1);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-home-1"></span><span class="ui-btn-inner'+choice_color[1]+'"><span class="ui-btn-text" style="margin-left:-1em;margin-right:-1em;">首页</span></span></label></li><li class="ui-block-b"><input type="radio" '+str[2]+' name="radiof1" id="radio-f1b" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(2);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-home-2"></span><span class="ui-btn-inner'+choice_color[2]+'"><span class="ui-btn-text" style="margin-left:-1em;margin-right:-1em;">理财产品</span></span></label></li><li class="ui-block-c"><input type="radio" '+str[3]+' name="radiof1" id="radio-f1c" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(3);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-home-3"></span><span class="ui-btn-inner'+choice_color[3]+'"><span class="ui-btn-text" style="margin-left:-1em;margin-right:-1em;">个人中心</span></span></label></li><li class="ui-block-d"><input type="radio" '+str[4]+' name="radiof1" id="radio-f1d" class="ui-hide"><label onclick="uexWindow.evaluateScript(\'\',\'0\',\'disopen(4);\');" class="ui-btn ui-btn-icon-top"><span class="ui-icon ui-pic-home-4"></span><span class="ui-btn-inner'+choice_color[4]+'"><span class="ui-btn-text" style="margin-left:-1em;margin-right:-1em;">更多</span></span></label></li>';
 	setHtml(footid,res);
 }
 