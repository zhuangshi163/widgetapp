var url_com = "http://te.3g2win.com/wordpress/";
//var url_com = "http://www.iflim.net/0/";
//var url_com = "http://www.lxydblog.com/"; 
//var url_com = "http://www.blouho.com/";
 
var httpUrl = url_com + "?callback=?";

var serverurl=url_com;
var url_end ="?callback=?";

var showtime_url=serverurl+url_end+"&zywxapp/content/list/products&limit=3";
var showtime_detail_url=serverurl+url_end+"&zywxapp/content/product/";

var bound_number_url=serverurl+url_end+"&zywxapp/user/login/";
var my_profile_url=serverurl+url_end+"&zywxapp/content/user/";
var edit_url=serverurl+url_end+"&zywxapp/user/edit/";
var exit_url=serverurl+url_end+"&zywxapp/user/logout/";
var search_url=serverurl+url_end+"&zywxapp/search&keyword=";
var class_url=serverurl+url_end+"&zywxapp/content/list/categories&limit=8";
var label_url=serverurl+url_end+"&zywxapp/content/list/tags&limit=8";

function getFirstArticleUrl(type,num){
	return httpUrl + "&zywxapp/content/list/posts/&type="+type+"&limit="+num;
}
function getNextArticleUrl(type,lid,num){
//	return httpUrl + "&zywxapp/content/list/posts/&type="+type+"&down="+lid+"&limit="+num;
	return httpUrl + "&zywxapp/content/list/posts/&type="+type+"&since_time="+lid+"&limit="+num;
}
function getPreArticleUrl(type,lid,num){
//	return httpUrl + "&zywxapp/content/list/posts/&type="+type+"&up="+lid+"&limit="+num;
	return httpUrl + "&zywxapp/content/list/posts/&type="+type+"&max_time="+lid+"&limit="+num;
}