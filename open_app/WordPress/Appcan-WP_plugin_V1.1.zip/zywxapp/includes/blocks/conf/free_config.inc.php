<?php 

$envSettings = array(
	'plugin_name' => 'wordpress',
	'api_key' => random(4).'enl3eHp5d3h6eXd4'.random(4),
	'api_server' => 'te.tx100.com/proxyserver',
	'cdn_server' => 'www.appcan.cn',
	'secure_cdn_server' => 'www.appcan.cn',
    'installation_source' => 'free-env',
);
