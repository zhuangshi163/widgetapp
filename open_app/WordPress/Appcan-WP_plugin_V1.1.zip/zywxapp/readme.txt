=== ZywxApp – create your own native iphone app. ===
Contributors: zywxapp
Tags: Iphone, iphone app, appstore, App Store, native, ipod, ios, iphone theme, mac,mobile app, apple, Smartphone, Mobile, mobile app, Android app, Android
Requires at least: 3.3.0
Tested up to: 3.3.2
Stable tag: v1.1.0
License: GPLv2

== Description ==

= Just ‘plugin’ and play! = 

ZywxApp is a plugin that turns your WordPress powered site into a native iPhone App. Imagine, your personal site, can now be searched, found and downloaded through the App Store by avid fans worldwide!
[Take the tour](http://appcan.cn/) for more information.