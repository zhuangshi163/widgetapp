<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//手机小图标链接到下载页
$tplfile = DISCUZ_ROOT.$_G['style']['tpldir'].'/forum/viewthread_node.htm';
@copy($tplfile, $tplfile.'.bak');
$tplcontent = file_get_contents($tplfile);
$tplcontent = preg_replace('/href="misc.php\?mod=mobile"/', 'href="plugin.php?id=zywx:propagate"', $tplcontent);
if($tplcontent && dir_writeable(DISCUZ_ROOT.$_G['style']['tpldir'])) {
	@file_put_contents($tplfile, $tplcontent);
}

if(is_intranet()) {
	plugin_uninstall();
	cpmsg('&#20869;&#32593;&#19981;&#33021;&#20351;&#29992;&#27492;&#25554;&#20214;', '', 'error');
}

$appkey = random(4).'enl3eHp5d3h6eXd4'.random(4);

include DISCUZ_ROOT.'./source/plugin/zywx/config.php';

$data = get_url_contents(ZYWX_PROXY.'/index.php?m=curl&plugin_name=discuz&a=guid&domain='.$_G['siteurl'].'&appkey='.$appkey);
$data = json_decode($data);
	
if($data->zywxid) {
	DB::query("replace into ".DB::table('common_setting')." set skey='zywxid' ,svalue='".$data->zywxid."'");
		
	if($data->zywxappkey) {
		DB::query("replace into ".DB::table('common_setting')." set skey='zywxappkey' ,svalue='".$data->zywxappkey."'");
	}
		
	if($data->zywxemail) {
		DB::query("replace into ".DB::table('common_setting')." set skey='zywxemail' ,svalue='".$data->zywxemail."'");
	}
	
	if($data->app_version) {
		DB::query("replace into ".DB::table('common_setting')." set skey='zywxversion' ,svalue='".$data->app_version."'");
	}
	
} elseif($data->msg) {
	plugin_uninstall();
	cpmsg(utf8togbk($data->msg), '', 'error');
} else {
	plugin_uninstall();
	cpmsg('
&#25265;&#27465;&#65292;&#36828;&#31243;&#26381;&#21153;&#22120;&#19981;&#21487;&#29992;&#65292;&#35831;&#32852;&#31995;&#27492;&#25554;&#20214;&#23448;&#26041;&#23458;&#26381;&#20154;&#21592;', '', 'error');
}


$sql = "
DROP TABLE IF EXISTS `".DB::table('zywx_useroperation')."`;
CREATE TABLE `".DB::table('zywx_useroperation')."` (
  `uid` INT( 11 ) NOT NULL ,
  `username` VARCHAR(100) NOT NULL,
  `phone_name` VARCHAR(100) NOT NULL,
  `latitude`   VARCHAR(30)  NOT NULL default '0',
  `longitude`   VARCHAR(30)  NOT NULL default '0',
  `allow_state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
   KEY `uid` (`uid`),
   KEY `dateline` (`dateline`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `".DB::table('zywx_useroperation_log')."`;
CREATE TABLE `".DB::table('zywx_useroperation_log')."` (
  `uid` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `phone_name` varchar(100) NOT NULL,
  `latitude` varchar(30) NOT NULL default '0',
  `longitude` varchar(30) NOT NULL default '0',
  `allow_state` tinyint(1) unsigned NOT NULL default '1',
  `dateline` int(10) unsigned NOT NULL default '0',
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `".DB::table('zywx_forum_postfield')."`;
CREATE TABLE  `".DB::table('zywx_forum_postfield')."` (
 `pid` INT( 10 ) UNSIGNED NOT NULL DEFAULT  '0',
 `longitude` CHAR( 15 ) NOT NULL ,
 `latitude` CHAR( 15 ) NOT NULL ,
 `device` CHAR( 30 ) NOT NULL ,
 `address` VARCHAR( 255 ) NOT NULL,
 `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY ( `pid` ) 
) ENGINE = MYISAM;

DROP TABLE IF EXISTS `".DB::table('zywx_home_blogfield')."`;
CREATE TABLE  `".DB::table('zywx_home_blogfield')."` (
 `blogid` INT( 10 ) UNSIGNED NOT NULL DEFAULT  '0',
 `longitude` CHAR( 15 ) NOT NULL ,
 `latitude` CHAR( 15 ) NOT NULL ,
 `device` CHAR( 30 ) NOT NULL ,
 `address` VARCHAR( 255 ) NOT NULL,
 `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY ( `blogid` ) 
) ENGINE = MYISAM;
";

zywx_runquery($sql);

//###################相册表############################

if(!fieldexist("home_album", "isPhone")) {
	$sql = "ALTER TABLE  `".DB::table('home_album')."` 
			ADD  `isPhone` TINYINT( 1 ) NOT NULL DEFAULT  '0';";
	zywx_runquery($sql);		
}

$_SESSION['linklocation'] = 1;
$_SESSION['ispopwin'] = 1;
//保存设置到数据库
zy_savecache('zywxdata', $_SESSION);
$finish = TRUE;

function is_intranet() {
	return preg_match('/^(127|192|local)/', $_SERVER['HTTP_HOST']);
}

function fieldexist($table, $field) {
	$sql= "Describe ".DB::table($table)." $field";
	return DB::fetch(DB::query($sql));
}

function plugin_uninstall(){
	DB::query("DELETE FROM ".DB::table('common_plugin')." WHERE identifier='zywx'");
}

function zywx_runquery($sql) {
	global $_G;
	$tablepre = $_G['config']['db'][1]['tablepre'];
	$dbcharset = $_G['config']['db'][1]['dbcharset'];
	
	$sql = str_replace("\r", "\n", str_replace(array(' {tablepre}', ' `{tablepre}'), array(' '.$tablepre, ' `'.$tablepre), $sql));

	$ret = array();
	$num = 0;
	foreach(explode(";\n", trim($sql)) as $query) {
		$queries = explode("\n", trim($query));
		foreach($queries as $query) {
			$ret[$num] .= $query[0] == '#' || $query[0].$query[1] == '--' ? '' : $query;
		}
		$num++;
	}
	unset($sql);

	foreach($ret as $query) {
		$query = trim($query);
		if($query) {

			if(substr($query, 0, 12) == 'CREATE TABLE') {
				$name = preg_replace("/CREATE TABLE ([a-z0-9_]+) .*/is", "\\1", $query);
				DB::query(createtable($query, $dbcharset));

			} else {
				DB::query($query);
			}

		}
	}
}

function utf8togbk($data) {
	if(CHARSET != 'utf-8') {
		$data = diconv($data, 'utf-8', CHARSET);
	}
	return $data;
}
/**
 * 缓存保存到数据库
 * @param   string  $name    键名
 * @param   mixed   $data    缓存内容
 * @param   int     $life    缓存存活时间，默认为一周
 */
function zy_savecache($name, $data, $life=604800) {
	DB::insert('common_syscache', array(
		'cname' => $name,
		'data' => serialize($data),
		'dateline' => (TIMESTAMP+$life)
	), false, true);
}

?>