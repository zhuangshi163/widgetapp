<?php
/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: uninstall.php 20324 2011-02-21 09:35:00Z zhengqingpeng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//手机小图标链接到下载页
$tplfile = DISCUZ_ROOT.$_G['style']['tpldir'].'/forum/viewthread_node.htm';
$tplcontent = file_get_contents($tplfile);
$tplcontent = preg_replace('/href="plugin.php\?id=zywx:propagate"/', 'href="misc.php?mod=mobile"', $tplcontent);
if($tplcontent && dir_writeable(DISCUZ_ROOT.$_G['style']['tpldir'])) {
	@file_put_contents($tplfile, $tplcontent);
}

include DISCUZ_ROOT.'./source/plugin/zywx/config.php';

//删除广告位
$config = DB::fetch(DB::query('SELECT data, dateline FROM '.DB::table("common_syscache")." WHERE cname='zywxdata' LIMIT 1"));
$config = unserialize($config['data']);

if($config['pullscreenid']) {
	zywx_runquery("DELETE FROM ".DB::table('common_advertisement')." 
		  	  WHERE advid='$config[pullscreenid]'");
}
updatecache('advs');

//删除内容设置保存值
zywx_runquery("DELETE FROM ".DB::table('common_syscache')." 
		  WHERE cname='zywxdata'");
//删除登录保存值
zywx_runquery("DELETE FROM ".DB::table('common_syscache')." 
		  WHERE cname='zywx_islogin'");
//删除创建应用时的锁
zywx_runquery("DELETE FROM ".DB::table('common_syscache')." 
		  WHERE cname='zywx_reg_lock'");
//关于推广的锁文件
zywx_runquery("DELETE FROM ".DB::table('common_syscache')." 
		  WHERE cname='zywx_channel_invited'");
//关于appid
zywx_runquery("DELETE FROM ".DB::table('common_syscache')." 
		  WHERE cname='zywx_appid'");
session_start();		  
session_unset();

$sql = "
DROP TABLE IF EXISTS `".DB::table('zywx_useroperation')."`;
DROP TABLE IF EXISTS `".DB::table('zywx_useroperation_log')."`;
DROP TABLE IF EXISTS `".DB::table('zywx_forum_postfield')."`;
DROP TABLE IF EXISTS `".DB::table('zywx_home_blogfield')."`;
DELETE FROM `".DB::table('common_setting')."` WHERE skey IN('zywxversion', 'zywxemail', 'zywxid', 'zywxappkey', 'zywx_version', 'zywx_email');
";
zywx_runquery($sql);

//平台记录插件卸载状态
get_url_contents(ZYWX_APPCAN.'/plugin/installStatus.action?app_key='.$_G['setting']['zywxappkey'].'&status=0');

$finish = TRUE;


function fieldexist($table, $field) {
	$sql= "Describe ".DB::table($table)." $field";
	return DB::fetch(DB::query($sql));
}

function zywx_runquery($sql) {
	global $_G;
	$tablepre = $_G['config']['db'][1]['tablepre'];
	$dbcharset = $_G['config']['db'][1]['dbcharset'];
	
	$sql = str_replace("\r", "\n", str_replace(array(' {tablepre}', ' `{tablepre}'), array(' '.$tablepre, ' `'.$tablepre), $sql));

	$ret = array();
	$num = 0;
	foreach(explode(";\n", trim($sql)) as $query) {
		$queries = explode("\n", trim($query));
		foreach($queries as $query) {
			$ret[$num] .= $query[0] == '#' || $query[0].$query[1] == '--' ? '' : $query;
		}
		$num++;
	}
	unset($sql);

	foreach($ret as $query) {
		$query = trim($query);
		if($query) {

			if(substr($query, 0, 12) == 'CREATE TABLE') {
				$name = preg_replace("/CREATE TABLE ([a-z0-9_]+) .*/is", "\\1", $query);
				DB::query(createtable($query, $dbcharset));

			} else {
				DB::query($query);
			}

		}
	}
}

?>