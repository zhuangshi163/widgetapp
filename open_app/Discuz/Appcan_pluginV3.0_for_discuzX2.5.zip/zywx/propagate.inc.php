<?php
include DISCUZ_ROOT.'./source/plugin/zywx/config.php';
include DISCUZ_ROOT.'./source/plugin/zywx/qrcode.class.php';
$config = zy_loadcache('zywxdata', false);
$appkey = $_G['setting']['zywxappkey'];

if($_GET['download']) {
	download_package();
	exit();
}


//web下载地址
$appid = zy_loadcache('zywx_appid', false);
$i = get_url_contents(ZYWX_APPCAN."/plugin/getDownload.action?app_key=$appkey&pt=iPhone");
$a = get_url_contents(ZYWX_APPCAN."/plugin/getDownload.action?app_key=$appkey&pt=Android");
$i = explode('|', $i);
$a = explode('|', $a);
if(!empty($i[1]) && !empty($a[1])) {
	
	preg_match('/\/(\d+)\//s', $i[1], $match);
	if ($match[1] && $match[1] != $appid) {	
		zy_savecache('zywx_appid', $match[1]);
	}
	$downloadurl = $i[1];
	$webqrfileapi = $_G['siteurl'].'data/attachment/mobile_qrcodeapi.png';
	$qruploadapi = './data/attachment/mobile_qrcodeapi.png';
	QRcode::png($downloadurl, $qruploadapi);
	
	$downloadurlanzhuo = $a[1];
	$webqrfileapianzhuo = $_G['siteurl'].'data/attachment/mobile_qrcodeapianzhuo.png';
	$qruploadapianzhuo = './data/attachment/mobile_qrcodeapianzhuo.png';
	QRcode::png($downloadurlanzhuo, $qruploadapianzhuo);
		
}
if(isset($_GET['dl'])) {
	dheader('Location:'.$downloadurl);
}

$iphone_src = get_local_package('iPhone');
$iPhone_srclijidown = get_local_package('iPhonedown');
if($iphone_src) {

	$webqrfile = $_G['siteurl'].'data/attachment/mobile_qrcodeiphone.png';
	$qrfileupload = './data/attachment/mobile_qrcodeiphone.png';
	QRcode::png($iphone_src, $qrfileupload);
} else {
	$iphone_thumbsrc = $webqrfileapi;
}

$android_src = get_local_package('Android');
$android_srclijidown = get_local_package('Androiddown');
if($android_src) {
	
	$webqrfilean = $_G['siteurl'].'data/attachment/mobile_qrcodeandroid.png';
	$qrfileuploadan = './data/attachment/mobile_qrcodeandroid.png';
	QRcode::png($android_src, $qrfileuploadan);

} else {
	$android_thumbsrc = $webqrfileapianzhuo;
}

include template('zywx:propagate');

function download_package() {
	global $_G, $config, $appkey;
	$local_src = get_local_package($_GET['os']);

	if($local_src) {
		dheader('Location:'.$local_src);
	}

	$data = get_url_contents(ZYWX_APPCAN."/plugin/getDownload.action?app_key=$appkey&pt=$_GET[os]");
	$data = explode('|', $data);

	if($data[0]) {
		dheader('Location:'.$data[0]);
	} else {
		showmessage('&#25265;&#27465;&#65292;&#27809;&#26377;&#21253;&#19979;&#36733;');
	}
}

function get_local_package($os) {
	global $_G, $config;	
	$key = array('iPhone' => 'iphone_src', 'Android' => 'android_src', 'iPhonedown' => 'iphone_srclijidown', 'Androiddown' => 'android_srclijidown');
	$local_src = $config[$key[$os]];
	
	if($local_src) {
		if(preg_match('/^http:\/\//', $local_src)) {
			return $local_src;
		}
		 else
		{
			if(file_exists(DISCUZ_ROOT.'source/plugin/zywx/'.$local_src)) {
				return $_G['siteurl'].'source/plugin/zywx/'.$local_src;
		     }
		}
	}
}

function zy_loadcache($name, $limit=true) {
	$cache = DB::fetch(DB::query('SELECT data, dateline FROM '.DB::table("common_syscache")." WHERE cname='$name' LIMIT 1"));
	if(empty($cache) || ($limit && TIMESTAMP > $cache['dateline'])) return;
	return unserialize($cache['data']);
}

function zy_savecache($name, $data, $life=604800) {
	DB::insert('common_syscache', array(
		'cname' => $name,
		'data' => serialize($data),
		'dateline' => (TIMESTAMP+$life)
	), false, true);
}

?>