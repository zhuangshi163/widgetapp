<?php
/*
	AppCan后台设置
*/

set_time_limit(0);
include DISCUZ_ROOT.'./source/plugin/zywx/config.php';

/**
 * 如果SESSION为空则从数据库
 * 中取出此配置信息并放入SESSION
 */
$config = zy_loadcache('zywxdata', false);		
if(is_array($config)) {
	$_SESSION = $config;
}
$version = DB::fetch_first("SELECT svalue FROM ".DB::table('common_setting')."
							WHERE skey='zywxversion'");
$zywxemail = DB::fetch_first("SELECT svalue FROM ".DB::table('common_setting')."
							WHERE skey='zywxemail'");
$zywxemail = $zywxemail['svalue'];
$version = $version['svalue'];
$islogin = zy_loadcache('zywx_islogin');

/**
* 当前脚本路径
*/
$url = $_G['siteurl']."admin.php?action=plugins&operation=config&do=$pluginid&identifier=zywx&pmod=main";

/**
 * 表单POST过来的数据，会由post.inc.php
 * 专门对POST数据处理
 */
if($_POST) {
	//echo "<pre>";
	//print_r($_POST);exit;
	require ZYWX_PATH.'/post.inc.php';
}

/**
 * 判断插件用户登录回调方法
 */
if($_G['gp_op'] == 'login' && empty($islogin)) {

	if(!$_G['gp_email']) {
		ob_start();
		include template('zywx:login');
		$body = ob_get_contents();
		ob_end_clean();
		$body = utf8togbk($body);
		echo $body;
		exit;
	} else {
		if($zywxemail == $_G['gp_email'] || empty($zywxemail)) {
			DB::insert('common_setting', array('skey' => 'zywxemail', 'svalue' => $_G['gp_email']), 0, 1);	
		}
		updatecache('setting');
		zy_savecache('zywx_islogin', 'ok', 1800);	

	}
}

/**
 * 查看当前用户是否登录
 */
if(empty($islogin)) {
	$_G['gp_op'] = 't_login';
}
/**
 * 未注册显示注册页面、未登录进入登录页面
 */
if($_G['gp_op'] == 't_login') {

	if(!$zywxemail) {
		ob_start();
		include template('zywx:setemail');
		$body = ob_get_contents();
		ob_clean();
		$body = utf8togbk($body);
		echo $body;
		exit;
	} else {

		ob_start();
		include template('zywx:setlogin');
		$body = ob_get_contents();
		ob_clean();
		$body = utf8togbk($body);
		echo $body;
		exit;
	}
}
$appkeyarr = DB::fetch_first("SELECT svalue FROM ".DB::table('common_setting')." WHERE skey='zywxappkey'");
$appkey = $appkeyarr['svalue'];

/**
 * 如果setting表中没有应用appkey的话
 * 会执行下面的IF从服务器获取appkey
 * 并保存在setting表中
 * 提示信息：请不要重复请求，服务器正在创建用户，请稍后
 */
$reg_lock = zy_loadcache('zywx_reg_lock');
if(!$appkey) {
	if($reg_lock) {
		cpmsgwx('&#35831;&#19981;&#35201;&#37325;&#22797;&#35831;&#27714;&#65292;&#26381;&#21153;&#22120;&#27491;&#22312;&#21019;&#24314;&#29992;&#25143;&#65292;&#35831;&#31245;&#21518;','','error');
	}

	cpmsgwx('&#26381;&#21153;&#22120;&#27491;&#22312;&#21019;&#24314;&#29992;&#25143;&#65292;&#35831;&#31245;&#21518;','','loading', '' , '' , '', TRUE);
	ob_flush();
	flush();

	zy_savecache('zywx_reg_lock', '1', 1800);
	$data = trim(get_url_contents(ZYWX_PROXY."/index.php?m=curl&a=registeApp&pluginName=discuz".
								   "&domain=".$_G['siteurl'].
								   "&authcode=".trim($_G['setting']['zywxid'])));

	$data = json_decode($data);
	echo "<script>$('cpcontainer').innerHTML='';</script><br/><br/>";
	ob_flush();
	flush();

	if($data->msg) {
		$message = $data->msg;
		$message = utf8togbk($message);
		zy_savecache('zywx_reg_lock', '0');
		cpmsgwx($message, $url, 'error', 1);
	} elseif($data->appkey) {
		$appkey = $data->appkey;
		DB::insert('common_setting', array('skey' => 'zywxappkey', 'svalue' => $appkey), true, true);
		updatecache('setting');
		zy_savecache('zywx_reg_lock', '0');
		cpmsgwx('&#27880;&#20876;&#29992;&#25143;&#25104;&#21151;', $url, 'succeed');
	} else {
		zy_savecache('zywx_reg_lock', '0');
		cpmsgwx('&#25265;&#27465;&#65292;&#36828;&#31243;&#26381;&#21153;&#22120;&#21709;&#24212;&#36229;&#26102;&#65292;&#35831;&#32852;&#31995;&#25554;&#20214;&#25552;&#20379;&#21830;', '' ,'error', 1);
	}
}

/**
 * 重新打包时，会传过来version参数
 * 如果参数中的应用 版本号大于当前版本号
 * 则把参数中的版本号保存到setting中
 * 保证本地表数据与appcan版本同步
 * 并更新setting缓存
 */
if($_G['gp_version']) {
		$version = $_G['gp_version'];
		$_SESSION['step'] = $_G['gp_op'] = 'selectstyle';
		DB::insert('common_setting', array('skey' => 'zywxversion', 'svalue' => $_G['gp_version']) , true, true);
		updatecache('setting');
}

/**
 * 从setting表中取出应用的版本号
 * 如果不存在 默认首次进入风格定制页面
 */
if(empty($version)) {

	$_SESSION['step'] = $_G['gp_op'] = 'selectstyle';
} else {
	if(!$_G['gp_version']) {
		$wxflagdata = array('setbuild','app_manager','data_count','setcontent','user_manager','custom','publicity','app_dabao');
		if(!in_array($_G['gp_op'],$wxflagdata)) {
			$_SESSION['step'] = $_G['gp_op'] = 'contrl';	
		}		
	}
}

$version = $version ? $version : '0.1';

/**
 * 推广
 */
$invited = zy_loadcache('zywx_invited', false);
$channel_invited = zy_loadcache('zywx_channel_invited', false);	

if(!$invited && !$channel_invited) {
	if(!$invited && file_exists(DISCUZ_ROOT.'./source/plugin/zywx/channel.html')) {
		zy_savecache('zywx_invited', '1');
		$domain = dreadfile(DISCUZ_ROOT.'./source/plugin/zywx/channel.html');
		$invite_url = ZYWX_APPCAN."/plugin/inviteReport.action?".
							"domainName=".$domain.
							"&pluginName=discuz".
							"&app_key=".$_G['setting']['zywxappkey'];
							
		$data = json_decode(trim(get_url_contents($invite_url)));
		if($data->status == 'ok') {
			zy_savecache('zywx_invited', '1');
		} else {
			zy_savecache('zywx_invited', '0');
		}
	} else {
		$result = trim(get_url_contents("http://wgb.tx100.com/plugin/pluginInviteReg.action?channelCode={$channelCode}&siteUrl={$_G['siteurl']}"));
		$result = json_decode($result);
		if($result->status == 'ok') {
			if($result->msg) {
				zy_savecache('zywx_channel_invite_url', $result->msg);
			}
			zy_savecache('zywx_channel_invited', '1');
		} else {
			zy_savecache('zywx_channel_invited', '0');
		}	
	}
}

	
/**
 * 风格设置页面
 */
if($_G['gp_op'] == 'selectstyle') {
	ob_start();
	include template('zywx:selectstyle');
	$body = ob_get_contents();
	ob_clean();
	$body = utf8togbk($body);
	echo $body;
}

/**
 * 应用打包页面
 **/
if($_G['gp_op'] == 'app_dabao') {

	$iframeurl  = $_G['gp_url'] ? $_G['gp_url'] : ZYWX_APPCAN.'/plugin/new_plugin_detail';
	$jumpUrl = $iframeurl."?app_key=".$appkey;
	echo "<script language='javascript' type='text/javascript'>";
	echo "window.top.location.href='$jumpUrl'";
	echo "</script>";
	exit;
}

/**
 * 管理 应用页面
 **/
if($_G['gp_op'] == 'app_manager') {
	$jumpUrl = ZYWX_APPCAN."/app/index";
	echo "<script language='javascript' type='text/javascript'>";
	echo "window.top.location.href='$jumpUrl'";
	echo "</script>";
	exit;
}

/**
* 应用设置页面
*/
elseif($_G['gp_op'] == 'setbuild') {

	$iframeurl  = $_G['gp_url'] ? $_G['gp_url'] : ZYWX_APPCAN.'/plugin/new_plugin_pkg.action';
	$jumpUrl = $iframeurl."?app_key=".$appkey."&pluginName=discuz&pluginVersion=".$plugin['version'];
	echo "<script language='javascript' type='text/javascript'>";
	echo "window.top.location.href='$jumpUrl'";
	echo "</script>";
	exit;
}

/**
 * 数据统计页面
 **/
if($_G['gp_op'] == 'data_count') {
	$iframeurl  = $_G['gp_url'] ? $_G['gp_url'] : ZYWX_APPCAN.'/plugin/dataAnaly';
	$jumpUrl = $iframeurl."?app_key=".$appkey;
	echo "<script language='javascript' type='text/javascript'>";
	echo "window.top.location.href='$jumpUrl'";
	echo "</script>";
	exit;
}

/**
 * 我要定制页面（二次开发页面）
 */
if($_G['gp_op'] == 'custom') {
	ob_start();
	include template('zywx:custom');
	$body = ob_get_contents();
	ob_clean();
	$body = utf8togbk($body);
	echo $body;
}

/**
 * 控制面板页面
 */
if($_G['gp_op'] == 'contrl') {

	//wx提示升级
	$upgrade_url = ZYWX_PROXY."/index.php?m=curl&plugin_name=discuz&a=getNewestVersion";
	$newver = json_decode(file_get_contents($upgrade_url),true);
	$varflag = floatval($newver['version']);
	if($varflag > $plugin['version']) {			
		$upgrade = 1;										
	}
	//wx	
	ob_start();
	include template('zywx:contrl');
	$body = ob_get_contents();
	ob_clean();
	$body = utf8togbk($body);
	echo $body;
}

/**
 * 帐号管理页面
 */
if($_G['gp_op'] == 'user_manager') {
	ob_start();
	include template('zywx:user_manager');
	$body = ob_get_contents();
	ob_clean();
	$body = utf8togbk($body);
	echo $body;
}


/**
* 内容设置页面
*/
elseif($_G['gp_op'] == 'setcontent') {			
			
	if(empty($_SESSION['index_pic1']) && empty($_SESSION['index_pic2']) && empty($_SESSION['index_pic3'])) {
	   $_SESSION['index_pic_status'] = 0;
	} else {
	   $_SESSION['index_pic_status'] = 1;
	}
	if(empty($_SESSION['hot_post_pic1']) && empty($_SESSION['hot_post_pic2']) && empty($_SESSION['hot_post_pic3'])) {
	   $_SESSION['hot_post_pic_status'] = 0;
	} else {
		$_SESSION['hot_post_pic_status'] = 1;
	}
	zy_savecache('zywxdata', $_SESSION);		
	//论坛版块select
	require_once libfile('function/forumlist');
	$forumselect = '<select name="hideforum[]" size="10" multiple="multiple">
					<option value="">'.cplang('plugins_empty').'</option>'.
				    forumselect(FALSE, 0, $_SESSION['hideforum'], TRUE).
				    '</select>';
	//门户栏目select				
	$portalselect = portalselect($_SESSION['hideportal']);

	//wx提示升级
	$upgrade_url = ZYWX_PROXY."/index.php?m=curl&plugin_name=discuz&a=getNewestVersion";
	$newver = json_decode(file_get_contents($upgrade_url),true);
	$varflag = floatval($newver['version']);
	if($varflag > $plugin['version']) {			
		$upgrade = 1;										
	}
	//wx	
	$forumselect = gbktoutf8($forumselect, true);
	$portalselect = gbktoutf8($portalselect, true);
	$_SESSION = gbktoutf8($_SESSION, true);
		
	ob_start();	
	include template('zywx:setcontent');
	$body = ob_get_contents();
	ob_clean();
	$body = utf8togbk($body);
	echo $body;
}

/**
* 管理应用页面
*/
elseif($_G['gp_op'] == 'applist') {				
	$iframeurl  = ZYWX_APPCAN.'/plugin/plugin_app_detail.action';

	ob_start();	
	include template('zywx:setbuild');
	$body = ob_get_contents();
	ob_clean();									
	$body = utf8togbk($body);					
	echo $body;	
}

/**
* 行为统计页面
*/
elseif($_G['gp_op'] == 'stat') {			
		
	$perpage = 10;							
	$page = $_GET['page'] ? max(intval($_GET['page']), 1) : 1;		
	$start = ($page - 1) * $perpage;		
    if($_G['gp_start_time'] && $_G['gp_end_time']) {

        $start_time = strtotime($_G['gp_start_time']);
		$end_time = strtotime($_G['gp_end_time']);
		$wherearr[] = "dateline > $start_time AND dateline < $end_time";
		$postwhere = "AND p.dateline > $start_time AND p.dateline < $end_time";  //查询发帖数条件
    }

    if($_G['gp_username']) {
        $wherearr[] = "username like '%".$_G['gp_username']."%'";
        $usernameflag = $_G['gp_username'];
    }
    if($wherearr) {
       $where = ' AND '.implode(' AND ', $wherearr);
    }
    $total_post_num = 0;
    $total_login_num = 0;
    //所有用户最后一次登录时间
    $count = DB::num_rows(DB::query("SELECT uid,username,MAX(dateline) as lasttime FROM ".DB::table('zywx_useroperation_log')." WHERE allow_state =1 $where group by uid"));

     $query = DB::query("SELECT uid,username,MAX(dateline) as lasttime FROM ".DB::table('zywx_useroperation_log')." WHERE allow_state =1 $where group by uid ORDER BY lasttime DESC LIMIT ".$start.",".$perpage);
    while($cat = mysql_fetch_assoc($query)) {
        $cat['lasttime'] = date('Y-m-d', $cat['lasttime']);
        $cat['login_num'] = DB::num_rows(DB::query("SELECT uid FROM ".DB::table('zywx_useroperation_log')." WHERE allow_state =1 AND uid=$cat[uid] $where "));
        if(CHARSET == 'gbk') {
            $cat['username'] = gbktoutf8($cat['username'], true);
        }
        $cat['post_num'] = se_postofcon("AND fp.authorid=$cat[uid]",$postwhere);  //某人指定时间的发帖数
        $total_post_num = $total_post_num + $cat['post_num'];     //合计发帖数
        $total_login_num = $total_login_num + $cat['login_num'];     //合计登录次数
        $arr[] = $cat;
    }
    $total_loginname_num = count($arr);     //合计登录帐号

	if($_G['gp_export']) {

		ob_start();
		
		header("Content-type:application/vnd.ms-excel");
		header("Content-Disposition:filename=appcan_stat_page_$page.xls");
		
		echo "<table>";
		echo "	<tr>
					<td>最后登录时间</td>
				  	<td>登录帐号</td>
				 	<td>登录次数</td>
				  	<td>发帖数</td>
			 	</tr>"; 
		foreach($arr as $row) { 

			echo "	<tr>
					<td>".$row['dateline']."</td>
				  	<td>".$row['username']."</td>
				 	<td>".$row['login_num']."</td>
				  	<td>".$row['post_num']."</td>
			 	</tr>";  	 
		}
		
		echo "	<tr>
					<td>合计</td>
					<td>$total_loginname_num</td>
					<td>$total_login_num</td>
					<td>$total_post_num</td>
          		</tr>";
		echo "</table>";
		
		$body = ob_get_contents();
		ob_clean();
		$body = utf8togbk($body);
		echo $body;
		exit;
	}
	$paramstr = "&username=".$_G['gp_username']."&start_time=".$_G['gp_start_time']."&end_time=".$_G['gp_end_time'];
	$multipage = multi($count, $perpage, $page, $url."&op=stat".$paramstr, 1000);
	ob_start();
	include template('zywx:stat');
	$body = ob_get_contents();
	ob_end_clean();
	$body = utf8togbk($body);
	echo $body;
}

/**
* 宣传推广页面
*/
elseif($_G['gp_op'] == 'publicity') {

	ob_start();
	include template('zywx:publicity');
	$body = ob_get_contents();
	ob_end_clean();
	$body = utf8togbk($body);
	echo $body;
}

/**
 * 手拉手页面
 * 
 * @copyright  2011-2012 Bei Jing Zheng Yi Wireless
 * @since      File available since Release 1.0 -- 2012-3-16 下午02:55:50
 * @author author
 * 
 */
elseif($_G['gp_op'] == 'hand'){
	$getChannelPkgurl = ZYWX_PROXY."/index.php?m=curl&a=getChannelPkg&authcode=".trim($_G['setting']['zywxid']);
	$getgetGuideDocurl= ZYWX_PROXY."/index.php?m=curl&a=getGuideDoc&authcode=".trim($_G['setting']['zywxid']);
	ob_start();
	include template('zywx:index_hand');
	$body = ob_get_contents();
	ob_end_clean();
	$body = utf8togbk($body);		
	echo $body;
} 

/**
 * 邀请管理页面
 * 
 * @copyright  2011-2012 Bei Jing Zheng Yi Wireless
 * @since      File available since Release 1.0 -- 2012-3-16 下午02:55:50
 * @author author
 * 
 */
elseif($_G['gp_op'] == 'invite') {
	$channel_url = zy_loadcache('zywx_channel_invite_url', false);
	if($channel_url) {
		$inviteurl = $channel_url;
	} else {
		$inviteurl = get_url_contents(ZYWX_APPCAN."/plugin/invitedUrl.action?app_key=".$appkey);
	}
	include template('zywx:invited');
}

/**
* 应用升级设置
*/
elseif($_G['gp_op'] == 'setappupgrade') {

	ob_start();
	include template('zywx:setappupgrade');
	$body = ob_get_contents();
	ob_clean();
	$body = utf8togbk($body);		
	echo $body;
}

/**
* 搜索指定时间某用户的发帖数目
*参数: 指定发帖用户(AND fp.authorid=$v[uid])，条件(一个时间段))
*/
function se_postofcon($where1 = null,$where2 = null) {

     $sql = "SELECT COUNT(p.pid) AS count FROM ".DB::table('zywx_forum_postfield')." p LEFT JOIN ".DB::table('forum_post')." fp ON p.pid=fp.pid WHERE 1 $where1 $where2 LIMIT 1";
     $result = mysql_query($sql);
     $data = mysql_fetch_assoc($result);
     return $data['count'];
}

/**
 * 根据键名加载缓存
 * @param   string  $name    键名
 * @param   mixed   $life    是否受过期限制
 */
function zy_loadcache($name, $limit=true) {
	$cache = DB::fetch(DB::query('SELECT data, dateline FROM '.DB::table("common_syscache")." WHERE cname='$name' LIMIT 1"));
	if(empty($cache) || ($limit && TIMESTAMP > $cache['dateline'])) return;
	return unserialize($cache['data']);
}

/**
 * 缓存保存到数据库
 * @param   string  $name    键名
 * @param   mixed   $data    缓存内容
 * @param   int     $life    缓存存活时间，默认为一周
 */
function zy_savecache($name, $data, $life=604800) {
	DB::insert('common_syscache', array(
		'cname' => $name,
		'data' => serialize($data),
		'dateline' => (TIMESTAMP+$life)
	), false, true);
}

/**
 * 获取门户下拉列表
 * @param   string  $hidelist    列表选中项的id数组
 */
function portalselect($hidelist='') {	
	$select = '';
	
	$query = DB::query("SELECT catid, catname, articles FROM ".DB::table('portal_category')." 
						WHERE closed='0' AND upid='0'");

	while($cat = DB::fetch($query)) {
	
		$select .= '<option value="'.$cat['catid'].'" class="bold" '.(in_array($cat['catid'], $hidelist) ? ' selected' : '').'>'.$cat['catname'].'</option>';
		
		//二级栏目
		$branchquery = DB::query("SELECT catid, catname, articles FROM ".DB::table('portal_category')." 
							WHERE closed='0' AND upid='$cat[catid]'");
		while($branchcat = DB::fetch($branchquery)) {	
			
			$select .= '<option value="'.$branchcat['catid'].'" '.(in_array($branchcat['catid'], $hidelist) ? ' selected' : '').'>&nbsp;&nbsp;'.$branchcat['catname'].'</option>';

			//三级栏目			
			$leafquery = DB::query("SELECT catid, catname, articles FROM ".DB::table('portal_category')." 
								WHERE closed='0' AND upid='$branchcat[catid]'");
			while($leaf = DB::fetch($leafquery)) {	
				$select .= '<option value="'.$leaf['catid'].'" '.(in_array($leaf['catid'], $hidelist) ? ' selected' : '').'>&nbsp; &nbsp; &nbsp; '.$leaf['catname'].'</option>';
			}
		}
				
	}

	return '<select name="hideportal[]" size="10" multiple="multiple">
		   		<option value="">'.cplang('plugins_empty').'</option>'.
				$select.
		   '</select>';
}

function utf8togbk($data, $force = 0) {
	if(is_array($data)) {
		$keys = array_keys($data);
		foreach($keys as $key) {
			$val = $data[$key];
			unset($data[$key]);
			$data[$key] = utf8togbk($val, $force);
		}
	} else {
		if(CHARSET != 'utf-8' ||  $force) {
			$data = iconv('utf-8', CHARSET."//IGNORE", $data);
		}
	}
	return $data;
}

function gbktoutf8($data, $force = 0) {
	if(is_array($data)) {
		$keys = array_keys($data);
		foreach($keys as $key) {
			$val = $data[$key];
			unset($data[$key]);
			$data[$key] = gbktoutf8($val, $force);
		}
	} else {
		if(CHARSET != 'gbk' ||  $force) {
			$data = iconv(CHARSET, "utf-8//IGNORE", $data);
		}
	}
	return $data;
}

function dreadfile($filename) {
	$content = '';
	if(function_exists('file_get_contents')) {
		@$content = file_get_contents($filename);
	} else {
		if(@$fp = fopen($filename, 'r')) {
			@$content = fread($fp, filesize($filename));
			@fclose($fp);
		}
	}
	return $content;
}

function cpmsgwx($message, $url = '', $type = '', $values = array(), $extra = '', $halt = TRUE) {

	global $_G;
	$vars = explode(':', $message);
	$values['ADMINSCRIPT'] = ADMINSCRIPT;
	if(count($vars) == 2) {
		$message = lang('plugin/'.$vars[0], $vars[1], $values);
	} else {
		$message = cplang($message, $values);
	}
	switch($type) {
		case 'download':
		case 'succeed': $classname = 'infotitle2';break;
		case 'error': $classname = 'infotitle3';break;
		case 'loadingform': case 'loading': $classname = 'infotitle1';break;
		default: $classname = 'marginbot normal';break;
	}
	if($url) {
		$url = substr($url, 0, 5) == 'http:' ? $url : ADMINSCRIPT.'?'.$url;
	}
	$message = "<h4 class=\"$classname\">$message</h4>";
	$url .= $url && !empty($_G['gp_scrolltop']) ? '&scrolltop='.intval($_G['gp_scrolltop']) : '';

	if($type == 'form') {
		$message = "<form method=\"post\" action=\"$url\"><input type=\"hidden\" name=\"formhash\" value=\"".FORMHASH."\">".
			"<br />$message$extra<br />".
			"<p class=\"margintop\"><input type=\"submit\" class=\"btn\" name=\"confirmed\" value=\"".cplang('ok')."\"> &nbsp; \n".
			"<script type=\"text/javascript\">".
			"if(history.length > (BROWSER.ie ? 0 : 1)) document.write('<input type=\"button\" class=\"btn\" value=\"".cplang('cancel')."\" onClick=\"history.go(-1);\">');".
			"</script>".
			"</p></form><br />";
	} elseif($type == 'loadingform') {
		$message = "<form method=\"post\" action=\"$url\" id=\"loadingform\"><input type=\"hidden\" name=\"formhash\" value=\"".FORMHASH."\"><br />$message$extra<img src=\"static/image/admincp/ajax_loader.gif\" class=\"marginbot\" /><br />".
			'<p class="marginbot"><a href="###" onclick="$(\'loadingform\').submit();" class="lightlink">'.cplang('message_redirect').'</a></p></form><br /><script type="text/JavaScript">setTimeout("$(\'loadingform\').submit();", 2000);</script>';
	} else {
		$message .= $extra.($type == 'loading' ? '<img src="static/image/admincp/ajax_loader.gif" class="marginbot" />' : '');
		if($url) {
			if($type == 'button') {
				$message = "<br />$message<br /><p class=\"margintop\"><input type=\"submit\" class=\"btn\" name=\"submit\" value=\"".cplang('start')."\" onclick=\"location.href='$url'\" />";
			} else {
				$message .= '<p class="marginbot"><a href="'.$url.'" class="lightlink">'.cplang($type == 'download' ? 'message_download' : 'message_redirect').'</a></p>';
				$timeout = $type != 'loading' ? 10000 : 0;
				$message .= "<script type=\"text/JavaScript\">setTimeout(\"redirect('$url');\", $timeout);</script>";
			}
		}
	}

	if($halt) {
		echo '<h3>'.cplang('discuz_message').'</h3><div class="infobox">'.$message.'</div>';
		exit();
	} else {
		echo '<div class="infobox">'.$message.'</div>';
	}
}
?>