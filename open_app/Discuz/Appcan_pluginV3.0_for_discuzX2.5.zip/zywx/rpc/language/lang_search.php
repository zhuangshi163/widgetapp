<?php

/**
 * 搜索模块语言
 *
 * file_description
 *
 * LICENSE Aushi Copyright
 *
 * @copyright  2011-2012 Bei Jing Zheng Yi Wireless
 * @version    $Id: \$
 * @since      File available since Release 1.0 -- 2011-8-17 下午02:54:11
 * @author 　　LLX
 */

$lang = array(
	'portal' =>'文章',
	'forum'  =>'帖子',
	'blog'   =>'日志',
	'album'  =>'相册',
	'group'  =>'群组',

	'user_unlogin'=>'用户未登录,请先登录！'
);

?>