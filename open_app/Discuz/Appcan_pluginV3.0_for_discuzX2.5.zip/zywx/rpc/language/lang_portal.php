<?php
/**
 * 门户模块语言      
 */

$lang['portal_status_off'] = '门户功能没有开启';
$lang['portal_catetory_empty'] = '门户没有栏目';
$lang['portal_catid_formaterror'] = '栏目id格式错误';
$lang['portal_article_nothave'] = '门户没有此文章';
$lang['portal_article_notcomment'] = '暂无评论';
$lang['portal_parameter_error'] = '参数错误';
$lang['portal_article_favorited'] = '此文章已经收藏过了';
$lang['portal_notallow_comment'] = '抱歉，此栏目不允许评论';

?>