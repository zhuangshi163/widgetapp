<?php
/**
 * 发帖、回贴、编辑帖子处理
 * @copyright  2011-2012 Bei Jing Zheng Yi Wireless
 * @since      File available since Release 1.0 -- 2012-8-16 下午04:33:48
 * @author wangxin
*/

//如请求来源不为手机端，虽返回
//if(preg_match('/MSIE|Firefox|Chrome|Safari|Opera/i', $_SERVER['HTTP_USER_AGENT'])) return;

/*入库前处理一下编码、判断空值或非法值等操作*/

//如果没有登录，则不能进行下列操作

if(empty($_G['uid'])) {
	$msg = lang('message', 'to_login');
	
	jsonexit("{\"message\":\"$msg\", \"nologin\":\"1\"}");
}

//两次操作时间时隔
if(check_flood()) {
	$msg = rpclang('forum', 'post_flood_ctrl');
	$msg = sprintf($msg, $_G['setting']['floodctrl']);
	jsonexit("{\"message\":\"$msg\", \"flood\":\"1\"}");
}

//回贴
if($_GET['action'] == 'reply' && $_GET['replysubmit']) { 
	
	if($_GET['attachnew']) {
		$arr = array(
			'description' => '',
			'price' => 0,
			'isimage' => 1,
		);
		
		$_GET['attachnew'] = explode(',', $_GET['attachnew']);
		$_GET['attachnew'] = array_combine($_GET['attachnew'], $_GET['attachnew']);
		$_GET['price'] = '';
		$_GET['uploadalbum'] = 1;
		$_GET['usesig'] = 1;
		$_GET['allownoticeauthor'] = 1;
		
		foreach($_GET['attachnew'] as $key=>$aid) {
			$_GET['attachnew'][$key] = $arr;		
		}
	}
	
	//回复内容空值检查
	if(empty($_GET['message'])) {
		$msg = rpclang('forum', 'forum_reply_empty');
		jsonexit("{\"message\":\"$msg\"}");
	}
	
	if(CHARSET != 'utf-8') {
		
		$_G['gp_message'] = utf8togbk($_G['gp_message']);
		if($_G['gp_noticeauthor']) 
			$_G['gp_noticeauthor'] = utf8togbk($_G['gp_noticeauthor']);
		if($_G['gp_noticetrimstr']) 
			$_G['gp_noticetrimstr'] = utf8togbk($_G['gp_noticetrimstr']);
		if($_G['gp_noticeauthormsg']) 
			$_G['gp_noticeauthormsg'] = utf8togbk($_G['gp_noticeauthormsg']);
	}	
} 

//发帖
elseif($_GET['action'] == 'newthread' && $_GET['topicsubmit']) { 
	
	if($_GET['attachnew']) {
		$arr = array(
			'description' => '',
			'price' => 0,
			'isimage' => 1,
		);
		
		$_GET['attachnew'] = explode(',', $_GET['attachnew']);
		$_GET['attachnew'] = array_combine($_GET['attachnew'], $_GET['attachnew']);
		$_GET['price'] = '';
		$_GET['uploadalbum'] = 1;
		$_GET['usesig'] = 1;
		$_GET['allownoticeauthor'] = 1;
		
		foreach($_GET['attachnew'] as $key=>$aid) {
			$_GET['attachnew'][$key] = $arr;		
		}
	}


	//帖子标题空值检查
	if(empty($_GET['subject'])) {
		$msg = rpclang('forum', 'forum_topic_empty');
		jsonexit("{\"message\":\"$msg\"}");
	}
	
	//帖子内容空值检查
	if(empty($_GET['message'])) {
		$msg = rpclang('forum', 'forum_topicmessage_empty');
		jsonexit("{\"message\":\"$msg\"}");
	}
	
	//加广告
	//$_GET['message'] = rpclang('forum', 'ad') . $_GET['message'];
	
//	echo "subject".$_GET['subject']."<br>";
//	echo "message".$_GET['message']."<br>";
	
	if(CHARSET != 'utf-8') {
		//echo "ok<br>";
		$_G['gp_subject'] = utf8togbk($_G['gp_subject']);
		$_G['gp_message'] = utf8togbk($_G['gp_message']);
	}
}
//	echo "subjecthou".$_GET['subject']."<br>";
//	echo "messagehou".$_GET['message']."<br>";exit;

require RPC_DIR . '/dmodule/forum/forum_'.$mod.'.php';
ob_end_clean();

/*返回想要的json数据*/

//回帖
if($_GET['action'] == 'reply') {

	//返回回复的帖子id
	if($_GET['replysubmit']) {
		jsonexit("{\"pid\":\"$pid\"}");
	}
	
}

//发帖
elseif($_GET['action'] == 'newthread') { 
	
	if($_G['gp_topicsubmit']) {
		//echo "ok<br>";
		//echo $modnewthreads;exit;
		if(!empty($modnewthreads)) {
			jsonexit("{\"tid\":\"$tid\",\"status\":\"$modnewthreads\"}");
		}else{
			jsonexit("{\"tid\":\"$tid\"}");
		}		
	} else { //发帖页面初始化
		$forumname = gbktoutf8($_G['forum']['name']);
		$actiontitle = gbktoutf8(trim($actiontitle));

		jsonexit("{\"forumname\":\"$forumname\",\"actiontitle\":\"$actiontitle\", \"status\":\"$_G[forum][status]\"}");
	}
	
}

//编辑帖子
elseif($_GET['action'] == 'edit') { 
	
	if($_GET['editsubmit']) {
		jsonexit("{\"pid\":\"$pid\"}");
	} else { //编辑帖子页面初始化
		$jsonarr = array();
		$jsonarr[0] = $postinfo; //帖子信息
		$jsonarr[1] = array('forumname' => $_G['forum']['name'], 'status' => $_G['forum']['status']); //版块信息

		jsonexit($jsonarr);
	}
	
}

function check_flood() {
	global $_G;
	if(!$_G['group']['disablepostctrl'] && $_G['uid']) {
		$isflood = $_G['setting']['floodctrl'] && (TIMESTAMP - $_G['setting']['floodctrl'] <= getuserprofile('lastpost'));

		if(empty($isflood)) {
			return FALSE;
		} else {
			return TRUE;
		}
	}
	return FALSE;
}

?>