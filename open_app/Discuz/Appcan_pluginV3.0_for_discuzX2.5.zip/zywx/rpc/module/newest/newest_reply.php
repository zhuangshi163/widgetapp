<?php
/**
 * 最新回复
 * @copyright  2011-2012 Bei Jing Zheng Yi Wireless
 * @since      File available since Release 1.0 -- 2012-8-16 下午04:29:12
 * @author   wangxin
 * 
 */

$page = $_GET ['page'] ? getgpc ('page') : 1;
$reply_num = $_GET ['reply_num'] ? getgpc ('reply_num') : 20;

loadcache('zywxdata');
$config = unserialize($_G['cache']['zywxdata']);
$hideids =	$config['hideforum'];
//wx  根据帖子售价 扣去对应威望、金钱、贡献
$svalue = DB::getOne('SELECT svalue FROM '.DB::table("common_setting")." WHERE skey='creditstrans' LIMIT 1");
$flag = substr($svalue,2,1);
if($flag == 1) {
  $flag = "威望";
}elseif($flag == 2) {
  $flag = "金钱";
} else {
  $flag = "贡献";	
}
//wx
//最新回复总数
$num_total = 60;

if($num_total > $reply_num) {
	$pages = @ceil($num_total / $reply_num);
	$_G["zywy_totalpage"] = $pages;
}

/*MB add start*/
$jsonarr['zywy_curpage'] = $page;
$jsonarr['zywy_totalpage'] = $_G["zywy_totalpage"];
/*MB add end*/

$start = $reply_num * ($page-1);

$sql = "SELECT fp.message,t.*, f.name FROM " . DB::table ('forum_thread') . " AS t
            LEFT JOIN " . DB::table ('forum_post') . " AS fp ON  t.tid = fp.tid
			LEFT JOIN " . DB::table ('forum_forum') . " AS f ON f.fid=t.fid
			WHERE fp.first=0 AND t.lastpost = fp.dateline AND t.isgroup =0 AND t.displayorder>=0
			ORDER BY t.lastpost DESC LIMIT $start, $reply_num";
	
$newReply = DB::getAll($sql);

foreach($newReply as $key => $value) {
	if($value['readperm']) {
		$value['subject'] = $value['subject']."[阅读权限".$value['readperm']."]"; 
	}
	if($value['price']) {
		$value['subject'] = $value['subject']."[售价".$value['price'].$flag."]"; 
	}
	$value['dateline'] = dgmdate($value['dateline'], 'Y-n-j H:i');
	$value['lastpost'] = dgmdate($value['lastpost'], 'Y-n-j H:i');
    $value['message'] = preg_replace('/<.*?>|\[.*?\]/', '', $value['message']);
    $value['message'] = cutstr($value['message'], 20, $dot = ' ...');
	$newReply[$key] = $value;	
	if($hideids && in_array($value['fid'], $hideids)) {
		unset($newReply[$key]);
	}
}

if ($newReply){

	$jsonarr['ucurl'] = $_G["setting"]['ucenterurl'];
    $jsonarr['newReply']=$newReply;
	
	jsonexit ($jsonarr);
} else{
	jsonexit();
}
?>