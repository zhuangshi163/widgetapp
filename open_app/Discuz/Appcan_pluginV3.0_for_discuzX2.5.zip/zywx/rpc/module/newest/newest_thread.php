<?php
/**
 * 主题列表
 * @copyright  2011-2012 Bei Jing Zheng Yi Wireless
 * @since      File available since Release 1.0 -- 2012-8-16 下午04:29:12
 * @author wangxin
 * 
 */

/*$thread_num 显示数目*/
$page = $_GET ['page'] ? getgpc ('page') : 1;
$thread_num = $_GET ['thread_num'] ? getgpc ('thread_num') : 20;

loadcache('zywxdata');
$config = unserialize($_G['cache']['zywxdata']);
$hideids =	$config['hideforum'];

//wx  根据帖子售价 扣去对应威望、金钱、贡献
$svalue = DB::getOne('SELECT svalue FROM '.DB::table("common_setting")." WHERE skey='creditstrans' LIMIT 1");
$flag = substr($svalue,2,1);
if($flag == 1) {
  $flag = "威望";
}elseif($flag == 2) {
  $flag = "金钱";
} else {
  $flag = "贡献";	
}
//wx
if($config['newest_post'] && $page == 1) {
	$config['newest_post'] =  str_replace("\r\n", ',', $config['newest_post']);
	$config['newest_post'] =  str_replace(array(',,', ' '), ',', $config['newest_post']);
	
	$list = DB::getAll("SELECT fp.message,t.*,f.name FROM " . DB::table('forum_thread')." t
						LEFT JOIN ".DB::table('forum_post')." fp ON  t.tid = fp.tid
						LEFT JOIN ".DB::table('forum_forum')." f ON  t.fid=f.fid												
						WHERE fp.first=1 AND t.tid IN($config[newest_post])");
	foreach($list as $key => $value) {
		if($value['readperm']) {
			$value['subject'] = $value['subject']."[阅读权限".$value['readperm']."]"; 
		}
		if($value['price']) {
			$value['subject'] = $value['subject']."[售价".$value['price'].$flag."]"; 
		}
		$value['dateline'] = dgmdate($value['dateline'], 'Y-n-j H:i');
		$value['lastpost'] = dgmdate($value['lastpost'], 'Y-n-j H:i');
		preg_match_all("/\[attach\](.*)\[\/attach\]/Ui",$value['message'],$data_arr);             //上传的图片
		preg_match_all("/\[img*\](.*)\[\/img\]/Ui",$value['message'],$wang);                     //直接粘贴的图片
		preg_match_all("/\[img=(.*)\](.*)\[\/img\]/Ui",$value['message'],$xin);                  //网络图片地址
		if(!empty($xin[2])) {                //网络路片的地址;
			$value['img'] = $xin[2][0];
		}
		if(!empty($wang[1])) {              //直接粘贴的图片的地址;
			$value['img'] = $wang[1][0];
		}
		if(!empty($data_arr[1])) {           //取到上传的图片的aid;
			$aid = $data_arr[1][0];
			if($aid > 0) {
				$sql1 = "select tableid from ".DB::table('forum_attachment')." where aid=".$aid;    //取出类似201109/14/1137091zbkqvqkkkikok32.jpg
				$re1=DB::fetch_first($sql1);
				$num = $re1["tableid"];
				$sql2 = "select attachment from ".DB::table('forum_attachment_'.$num)." where aid=".$aid." LIMIT 1";
				$re2=DB::fetch_first($sql2);
				$value['img'] = $_G['siteurl'].$_G['setting']['attachurl']."/forum/".$re2["attachment"];
			}
		}
		if(!empty($value['img'])) {
		   $value['ifimg'] = 1;
		}
		$value['message'] = preg_replace('/<.*?>|\[.*?\]/', '', $value['message']);
		$value['message'] = cutstr($value['message'], 20, $dot = ' ...');
		$value['name'] = DB::getOne("SELECT name FROM " . DB::table('forum_forum')." WHERE fid='$value[fid]'");
		unset($value['fid']);
		$list[$key] = $value;
	}
}

//最新主题总数
$num_total = 60;

if($num_total > $thread_num) {
	$pages = @ceil($num_total / $thread_num);
	$_G["zywy_totalpage"] = $pages;
}

/*MB add start*/
$jsonarr['zywy_curpage'] = $page;
$jsonarr['zywy_totalpage'] = $_G["zywy_totalpage"];
/*MB add end*/

$start = $thread_num * ($page-1);

$sql = "SELECT fp.message,t.*, f.name FROM " . DB::table ('forum_thread') . " AS t
            LEFT JOIN ".DB::table('forum_post')." fp ON  t.tid = fp.tid
			LEFT JOIN " . DB::table ('forum_forum') . " AS f
			ON f.fid=t.fid
			WHERE fp.first=1 AND t.displayorder>=0
			ORDER BY t.tid DESC LIMIT $start, $thread_num";
	
$newThread = DB::getAll($sql);
foreach($newThread as $key => $value) {

	if($value['readperm']) {
		$value['subject'] = $value['subject']."[阅读权限".$value['readperm']."]"; 
	}
	if($value['price']) {
		$value['subject'] = $value['subject']."[售价".$value['price'].$flag."]"; 
	}
	$value['dateline'] = dgmdate($value['dateline'], 'Y-n-j H:i');
	$value['lastpost'] = dgmdate($value['lastpost'], 'Y-n-j H:i');
    $value['message'] = preg_replace('/<.*?>|\[.*?\]/', '', $value['message']);
    $value['message'] = cutstr($value['message'], 20, $dot = ' ...');
	$newThread[$key] = $value;
	if($hideids && in_array($value['fid'], $hideids)) {
		unset($newThread[$key]);
	}
}

if(is_array($list)) {
	$newThread = array_merge($list, $newThread);
}

if($newThread){
	
	$jsonarr['ucurl'] = $_G["setting"]['ucenterurl'];
    $jsonarr['newThread'] = $newThread;

	jsonexit($jsonarr);
} else{
	jsonexit();
}
?>