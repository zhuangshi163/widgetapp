<?php
 /**
 * 热门主题
 * @copyright  2011-2012 Bei Jing Zheng Yi Wireless
 * @since      File available since Release 1.0 -- 2012-8-16 下午04:29:12
 * @author wangxin
 *
 */
 
$page = $_GET ['page'] ? getgpc ('page') : 1;
$thread_num = $_GET ['thread_num'] ? getgpc ('thread_num') : 20;
$start = $thread_num * ($page-1);

/**
 * 缓存时间为1小时
 */
//$hotThread = zy_loadcache('zywx_hotthread_'.$page, 3600);

loadcache('zywxdata');
$config = unserialize($_G['cache']['zywxdata']);
$hideids =	$config['hideforum'];
//wx  根据帖子售价 扣去对应威望、金钱、贡献
$svalue = DB::getOne('SELECT svalue FROM '.DB::table("common_setting")." WHERE skey='creditstrans' LIMIT 1");
$flag = substr($svalue,2,1);
if($flag == 1) {
  $flag = "威望";
}elseif($flag == 2) {
  $flag = "金钱";
} else {
  $flag = "贡献";	
}
//wx

if($config['host_post'] && $page == 1) {
	
	$config['host_post'] =  str_replace("\r\n", ',', $config['host_post']);
	$config['host_post'] =  str_replace(array(',,', ' '), ',', $config['host_post']);
	
	$list = DB::getAll("SELECT fp.message,t.*,f.name  FROM " . DB::table('forum_thread')." t 
						LEFT JOIN ".DB::table('forum_post')." fp ON  t.tid = fp.tid
						LEFT JOIN ".DB::table('forum_forum')." f ON  t.fid=f.fid
						WHERE t.tid IN($config[host_post]) AND fp.first=1 AND t.displayorder>='0' ORDER BY t.replies DESC");

	foreach($list as $key => $value) {
		if($value['readperm']) {
			$value['subject'] = $value['subject']."[阅读权限".$value['readperm']."]"; 
		}
		if($value['price']) {
			$value['subject'] = $value['subject']."[售价".$value['price'].$flag."]"; 
		}
		$value['dateline'] = dgmdate($value['dateline'], 'Y-n-j H:i');
		$value['lastpost'] = dgmdate($value['lastpost'], 'Y-n-j H:i');
		preg_match_all("/\[attach\](.*)\[\/attach\]/Ui",$value['message'],$data_arr);
		preg_match_all("/\[img*\](.*)\[\/img\]/Ui",$value['message'],$wang);
		preg_match_all("/\[img=(.*)\](.*)\[\/img\]/Ui",$value['message'],$xin);
		
		
		if(!empty($xin[2])) {      
			$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$xin[2][0];
		}
		if(!empty($wang[1])) {
			
			$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$wang[1][0];
		}
		if(!empty($data_arr[1])) {
			$aid = $data_arr[1][0];
			if($aid > 0) {
				$sql1 = "select tableid from ".DB::table('forum_attachment')." where aid=".$aid;
				$re1=DB::fetch_first($sql1);
				$num = $re1["tableid"];
				$sql2 = "select attachment,remote from ".DB::table('forum_attachment_'.$num)." where aid=".$aid." LIMIT 1";
				$re2=DB::fetch_first($sql2);

				if(empty($re2["remote"])) {

					$loclattachurl = DB::fetch_first("SELECT svalue FROM ".DB::table('common_setting')." WHERE skey='attachurl'");
					$flag = strpos($loclattachurl['svalue'],'ttp://');
					if($flag) {
						$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$loclattachurl['svalue']."/forum/".$re2["attachment"];
					} else {	
						$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$_G['siteurl'].$_G['setting']['attachurl']."/forum/".$re2["attachment"];
					}
				} else {

					$sqlftp = "select svalue from ".DB::table('common_setting')." where skey='ftp'";
					$ftpval=DB::fetch_first($sqlftp);
					$ftpinfo = unserialize($ftpval[svalue]);
					$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$ftpinfo['attachurl']."/forum/".$re2["attachment"];
					
				}
				
			}
		}
		if(!empty($value['img'])) {
		   $value['ifimg'] = 1;
		}
		$value['message'] = preg_replace('/<.*?>|\[.*?\]/', '', $value['message']);
		$value['message'] = cutstr($value['message'], 50, $dot = ' ...');
		$value['name'] = DB::getOne("SELECT name FROM " . DB::table('forum_forum')." WHERE fid='$value[fid]'");
		unset($value['fid']);
		$list[$key] = $value;
	}
}

//热门主题总数
$num_total = 60;

if($num_total > $thread_num) {
	$pages = @ceil($num_total / $thread_num);
	$_G["zywy_totalpage"] = $pages;
}

$jsonarr['zywy_curpage'] = $page;
$jsonarr['zywy_totalpage'] = $_G["zywy_totalpage"];

$timestamp = TIMESTAMP - 604800;
$dateline = "t.dateline>='$timestamp' AND";

$hotThread = DB::getAll("SELECT fp.message,t.*, f.name
		FROM ".DB::table('forum_thread')." t
        LEFT JOIN ".DB::table('forum_post')." fp ON  t.tid = fp.tid
		LEFT JOIN ".DB::table('forum_forum')." f ON  t.fid=f.fid
		WHERE $dateline fp.first=1 AND t.displayorder>='0'
		ORDER BY t.replies DESC
		LIMIT 0, $thread_num");
	
foreach($hotThread as $key => $value) {
	if($value['readperm']) {
		$value['subject'] = $value['subject']."[阅读权限".$value['readperm']."]"; 
	}
	if($value['price']) {
		$value['subject'] = $value['subject']."[售价".$value['price'].$flag."]"; 
	}
	$value['dateline'] = dgmdate($value['dateline'], 'Y-n-j H:i');
	$value['lastpost'] = dgmdate($value['lastpost'], 'Y-n-j H:i');
    preg_match_all("/\[attach\](.*)\[\/attach\]/Ui",$value['message'],$data_arr);
    preg_match_all("/\[img*\](.*)\[\/img\]/Ui",$value['message'],$wang);
    preg_match_all("/\[img=(.*)\](.*)\[\/img\]/Ui",$value['message'],$xin);

    if(!empty($xin[2])) {

    	$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$xin[2][0];
    }
    if(!empty($wang[1])) {
    	
        $value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$wang[1][0];
    }
    if(!empty($data_arr[1])) {
        $aid = $data_arr[1][0];
        if($aid > 0) {
            $sql1 = "select tableid from ".DB::table('forum_attachment')." where aid=".$aid;    
            $re1=DB::fetch_first($sql1);
            $num = $re1["tableid"];
            $sql2 = "select attachment from ".DB::table('forum_attachment_'.$num)." where aid=".$aid." LIMIT 1";
            $re2=DB::fetch_first($sql2);

			if(empty($re2["remote"])) {
				$loclattachurl = DB::fetch_first("SELECT svalue FROM ".DB::table('common_setting')." WHERE skey='attachurl'");
				$flag = strpos($loclattachurl['svalue'],'ttp://');
				if($flag) {
					$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$loclattachurl['svalue']."/forum/".$re2["attachment"];
				} else {	
					$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$_G['siteurl'].$_G['setting']['attachurl']."/forum/".$re2["attachment"];
				}
			} else {			
				$sqlftp = "select svalue from ".DB::table('common_setting')." where skey='ftp'";    //取出ftp
				$ftpval=DB::fetch_first($sqlftp);
				$ftpinfo = unserialize($ftpval[svalue]);
				$value['img'] = $_G['siteurl'].'source/plugin/zywx/rpc/forum.php?mod=image&src='.$ftpinfo['attachurl']."/forum/".$re2["attachment"];
				
			}
        }
    }
    if(!empty($value['img'])) {
       $value['ifimg'] = 1;
    }
    $value['message'] = preg_replace('/<.*?>|\[.*?\]/', '', $value['message']);
    $value['message'] = cutstr($value['message'], 50, $dot = ' ...');
	$hotThread[$key] = $value;
	if($hideids && in_array($value['fid'], $hideids)) {
		unset($hotThread[$key]);
	}
}



if(is_array($list)) {
	$hotThread = array_merge($list, $hotThread);
}

if ($hotThread){
	$jsonarr['ucurl'] = $_G["setting"]['ucenterurl'];
    $jsonarr['hotThread']=$hotThread;

	jsonexit($jsonarr);
} else{
	jsonexit();
}
?>