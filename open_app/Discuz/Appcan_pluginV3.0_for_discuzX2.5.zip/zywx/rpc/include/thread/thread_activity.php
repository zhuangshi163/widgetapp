<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: space_pm.php 21555 2011-03-31 06:04:49Z svn_project_zhangjie $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$applylist = array();
$activity = DB::fetch_first("SELECT * FROM ".DB::table('forum_activity')." WHERE tid='$_G[tid]'");
$activityclose = $activity['expiration'] ? ($activity['expiration'] > TIMESTAMP ? 0 : 1) : 0;	 //活动是否已关闭  1关闭	
$activity['starttimefrom'] = dgmdate($activity['starttimefrom']);      //活动开始时间
$activity['starttimeto'] = $activity['starttimeto'] ? dgmdate($activity['starttimeto']) : 0;   //活动结束时间
$activity['expiration'] = $activity['expiration'] ? dgmdate($activity['expiration']) : 0;	   //报名截止日期
$activity['activityclose'] = $activityclose;
$activity['cls'] = $activity['class'];		//活动类型
unset($activity['class']);
unset($activity['applynumber']);

if($_G['uid']) {
	//报名ID
	$uidinfo = DB::fetch_first("SELECT applyid,verified FROM ".DB::table('forum_activityapply')." 
						WHERE tid='$post[tid]' AND uid='$_G[uid]'");	
	//if($uidinfo) {
		$activity['applyed'] = $uidinfo['applyid']?1:0;    //是否参加 1表示已参加 0还未参加申请
		$activity['appstatus'] =  $uidinfo['verified']?1:0; 		  //当前申请状态 1已通过  0正在申请中
	//}
	
}
//已报名人数
$activity['allapplynum'] = DB::getOne("SELECT COUNT(applyid) FROM ".DB::table('forum_activityapply')." 
						WHERE tid='$post[tid]'");
//剩余名额 = 需要的人数-已通过
$passnum = DB::getOne("SELECT COUNT(applyid) FROM ".DB::table('forum_activityapply')." 
						WHERE tid='$post[tid]' AND verified=1");
$activity['overnum'] = $activity['number'] - $passnum;


//$activity['attachurl'] = $activity['thumb'] = '';
if($activity['ufield']) {
	$activity['ufield'] = unserialize($activity['ufield']);
	if($activity['ufield']['userfield']) {
		$htmls = $settings = array();
		require_once libfile('function/profile');
		foreach($activity['ufield']['userfield'] as $fieldid) {
			if(empty($ufielddata['userfield'])) {
				$query = DB::query("SELECT ".implode(',', $activity['ufield']['userfield'])." FROM ".DB::table('common_member_profile')." WHERE uid='$_G[uid]'");
				$ufielddata['userfield'] = DB::fetch($query);
			}
			$html = profile_setting($fieldid, $ufielddata['userfield'], false, true);
			if($html) {
				$settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
				$htmls[$fieldid] = $html;
			}
		}
	}
} else {
	$activity['ufield'] = '';
}

if($activity['aid']) {
	$attach = DB::fetch_first("SELECT * FROM ".DB::table(getattachtablebytid($_G['tid']))." WHERE aid='$activity[aid]'");
	if($attach['isimage']) {
		$activity['attachurl'] = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/'.$attach['attachment'];
		if(!preg_match('/^http:\/\//', $activity['attachurl'])) {
			$activity['attachurl'] = $_G['siteurl'].$activity['attachurl'];
		}
	}
}
//echo "<pre>";
//print_r($activity);exit;
$post['activity'] = $activity;

?>