<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: space_friend.php 20975 2011-03-09 08:52:58Z wangxin $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$perpage = 10;
//控制每页显示的参数改变
$perpage = mob_perpage($perpage);

$list = $ols = $fuids = array();
$count = 0;
$page = empty($_GET['page'])?0:intval($_GET['page']);
if($page<1) $page = 1;
$start = ($page-1)*$perpage;

if(empty($_GET['view']) || $_GET['view'] == 'all') $_GET['view'] = 'me';


ckstart($start, $perpage);   //检查分页数是否合理(抱歉，分页数不在允许的范围内)
$widgetPage = "friend_list.html";

if($_GET['view'] == 'online') {
	$theurl = "home.php?mod=space&uid=$space[uid]&do=friend&view=online";
	$actives = array('me'=>' class="a"');

	space_merge($space, 'field_home');
	$wheresql = '';
	if($_GET['type']=='near') {
		$theurl = "home.php?mod=space&uid=$space[uid]&do=friend&view=online&type=near";
		$ip = explode('.', $_G['clientip']);
		$wheresql = " WHERE ip1='$ip[0]' AND ip2='$ip[1]' AND ip3='$ip[2]'";
	} elseif($_GET['type']=='friend') {
		$theurl = "home.php?mod=space&uid=$space[uid]&do=friend&view=online&type=friend";
		$space['feedfriend'] = !empty($space['feedfriend']) ? $space['feedfriend'] : -1;
		$wheresql = " WHERE uid IN ($space[feedfriend])";
	} elseif($_GET['type']=='member') {
		$theurl = "home.php?mod=space&uid=$space[uid]&do=friend&view=online&type=member";
		$wheresql = " WHERE uid>0";
	} else {
		$_GET['type']=='all';
		$theurl = "home.php?mod=space&uid=$space[uid]&do=friend&view=online&type=all";
		$wheresql = ' WHERE 1';
	}
	
	$theurl = str_replace('home.php', $widgetPage, $theurl);
	
	$count = DB::result(DB::query("SELECT COUNT(*) FROM ".DB::table('common_session')." $wheresql"), 0);
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table("common_session")." $wheresql AND invisible='0' ORDER BY lastactivity DESC LIMIT $start,$perpage");
		while($value = DB::fetch($query)) {

			if($value['magichidden']) {
				$count = $count - 1;
				continue;
			}
			if($_GET['type']=='near') {
				if($value['uid'] == $space['uid']) {
					$count = $count-1;
					continue;
				}
			}

			if(!$value['invisible']) $ols[$value['uid']] = $value['lastactivity'];
			$list[$value['uid']] = $value;
			$fuids[$value['uid']] = $value['uid'];
		}

		if($fuids) {
			require_once libfile('function/friend');
			friend_check($space['uid'], $fuids);

			$query = DB::query("SELECT cm.uid, cm.username, cmfh.recentnote FROM ".DB::table("common_member").' cm
				LEFT JOIN '.DB::table("common_member_field_home")." cmfh ON cmfh.uid=cm.uid
				WHERE cm.uid IN(".dimplode($fuids).")");
			while($value = DB::fetch($query)) {
				//$value['isfriend'] = $value['uid']==$space['uid'] || $_G["home_friend_".$space['uid'].'_'.$value['uid']] ? 1 : 0;
				//$list[$value['uid']] = array_merge($list[$value['uid']], $value);
				$list[$value['uid']] = $value;
			}
		}
	}
	
	//print_r($list); exit;
	$multi = multi($count, $perpage, $page, $theurl);

} elseif($_GET['view'] == 'visitor' || $_GET['view'] == 'trace') {

	$theurl = "home.php?mod=space&uid=$space[uid]&do=friend&view=$_GET[view]";
	$actives = array('me'=>' class="a"');
	$theurl = str_replace('home.php', $widgetPage, $theurl);
	
	if($_GET['view'] == 'visitor') {
		$count = DB::result(DB::query("SELECT COUNT(*) FROM ".DB::table('home_visitor')." main WHERE main.uid='$space[uid]'"), 0);
		$query = DB::query("SELECT main.vuid AS uid, main.vusername AS username, main.dateline
			FROM ".DB::table('home_visitor')." main
			WHERE main.uid='$space[uid]'
			ORDER BY main.dateline DESC
			LIMIT 10");
	} else {
		$count = DB::result(DB::query("SELECT COUNT(*) FROM ".DB::table('home_visitor')." main WHERE main.vuid='$space[uid]'"), 0);
		$query = DB::query("SELECT main.uid AS uid, main.dateline
			FROM ".DB::table('home_visitor')." main
			WHERE main.vuid='$space[uid]'
			ORDER BY main.dateline DESC
			LIMIT 10");
			
	}
	if($count) {
		while ($value = DB::fetch($query)) {
			$fuids[] = $value['uid'];
			$list[$value['uid']] = $value;
		}
	}
	$multi = multi($count, $perpage, $page, $theurl);

} elseif($_GET['view'] == 'blacklist') {

	$theurl = "home.php?mod=space&uid=$space[uid]&do=friend&view=$_GET[view]";
	$actives = array('me'=>' class="a"');
	$theurl = str_replace('home.php', $widgetPage, $theurl);
	
	$count = DB::result(DB::query("SELECT COUNT(*) FROM ".DB::table('home_blacklist')." main WHERE main.uid='$space[uid]'"), 0);
	if($count) {
		$query = DB::query("SELECT s.username, s.groupid, main.dateline, main.buid AS uid
			FROM ".DB::table('home_blacklist')." main
			LEFT JOIN ".DB::table('common_member')." s ON s.uid=main.buid
			WHERE main.uid='$space[uid]'
			ORDER BY main.dateline DESC
			LIMIT $start,$perpage");
		while ($value = DB::fetch($query)) {
			$value['isfriend'] = 0;
			$fuids[] = $value['uid'];
			$list[$value['uid']] = $value;
		}
	}
	$multi = multi($count, $perpage, $page, $theurl);

} else {

	$theurl = "home.php?mod=space&uid=$space[uid]&do=$do";
	$actives = array('me'=>' class="a"');
	$theurl = str_replace('home.php', $widgetPage, $theurl);
	
	$_GET['view'] = 'me';

	$wheresql = '';
	if($space['self']) {
		require_once libfile('function/friend');
		$groups = friend_group_list();    //加载站内认识的方式
		$group = !isset($_GET['group'])?'-1':intval($_GET['group']);
		if($group > -1) {
			$wheresql = "AND main.gid='$group'";
			$theurl .= "&group=$group";
		}
	}
	if($_GET['searchkey']) {
		$wheresql = "AND main.fusername LIKE '%$_GET[searchkey]%'";
		$theurl .= "&searchkey=$_GET[searchkey]";
	}

	$count = DB::result(DB::query("SELECT COUNT(*) FROM ".DB::table('home_friend')." main WHERE main.uid='$space[uid]' $wheresql"), 0);

//当前用户的好友数
	$friendnum = DB::result_first("SELECT friends FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]' LIMIT 1");

    //我访问的人有好友
	if($count) {

		$query = DB::query("SELECT main.fuid AS uid, main.gid, main.num, main.note FROM ".DB::table('home_friend')." main
			WHERE main.uid='$space[uid]' $wheresql
			ORDER BY main.num DESC, main.dateline DESC
			LIMIT $start,$perpage");
		while ($value = DB::fetch($query)) {
			$_G["home_friend_".$space['uid'].'_'.$value['uid']] = $value['isfriend'] = 1;
			$fuids[$value['uid']] = $value['uid'];
			$list[$value['uid']] = $value;
		}

       //我没有好友，我访问的人有好友
	} elseif($count != 0 && !$friendnum) {
        //家园特殊用户(推荐好友/明星会员)数据表
        //status 0 明星会员  1 推荐好友
		if($specialuser_count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('home_specialuser')." WHERE status = 1 AND uid != '$_G[uid]'")) {
			$query = DB::query("SELECT * FROM ".DB::table('home_specialuser')." WHERE status = 1 AND uid != '$_G[uid]' LIMIT 6");
			while($value = DB::fetch($query)) {
				$fuids[$value['uid']] = $value['uid'];   //将明星会员id存入数组
				$specialuser_list[$value['uid']] = $value;
			}
		}
        //用户session数据表
        //invisible 是否隐身(默认为0)
		if($online_count = DB::result_first("SELECT COUNT(*) FROM ".DB::table("common_session")." WHERE invisible='0' AND uid <> '$_G[uid]' AND uid <> '0'")) {
			$query = DB::query("SELECT * FROM ".DB::table("common_session")." WHERE invisible='0' AND uid <> '$_G[uid]' AND uid <> '0' ORDER BY lastactivity DESC LIMIT 6");
			while($value = DB::fetch($query)) {
				$fuids[$value['uid']] = $value['uid'];   //将除自己外在线用户id存入数组
				$oluids[$value['uid']] = $value['uid'];
				$online_list[$value['uid']] = $value;
			}
            //用户数据表、用户家园设置数据表
			$query = DB::query("SELECT cm.*, cmfh.* FROM ".DB::table("common_member").' cm
				LEFT JOIN '.DB::table("common_member_field_home")." cmfh ON cmfh.uid=cm.uid
				WHERE cm.uid IN(".dimplode($oluids).")");
			while($value = DB::fetch($query)) {
				$online_list[$value['uid']] = array_merge($online_list[$value['uid']], $value);   //在线用户的来自三个表的数据
			}

		}
	}

	$diymode = 1;
	if($space['self'] && ($_GET['from'] != 'space' || !$_G['status']['homestatus'])) $diymode = 0;
	if($diymode) {
		$theurl .= "&from=space";     //friend_list.html?mod=space&uid=3652&do=friend
	}

	$multi = multi($count, $perpage, $page, $theurl);

	if($space['self']) {
		$groupselect = array($group => ' class="a"');

		$maxfriendnum = checkperm('maxfriendnum');
		if($maxfriendnum) {
			$maxfriendnum = checkperm('maxfriendnum') + $space['addfriend'];
		}
	}
}

if($fuids) {
	$query = DB::query("SELECT * FROM ".DB::table('common_session')." WHERE uid IN (".dimplode($fuids).")");
	while ($value = DB::fetch($query)) {
        if(!empty($value)) {
            $list[$value['uid']]['islogin'] = 1;
        }
		if(!$value['magichidden'] && !$value['invisible']) {
			$ols[$value['uid']] = $value['lastactivity'];
		} elseif($list[$value['uid']] && !in_array($_GET['view'], array('me', 'trace', 'blacklist'))) {
			unset($list[$value['uid']]);
			$count = $count - 1;
		}
	}
	if($_GET['view'] != 'me') {
		require_once libfile('function/friend');
		friend_check($fuids);
	}
	
	//print_r($fuids);exit;
	
	//if($list) {
		/*$query = DB::query("SELECT cm.*, cmfh.* FROM ".DB::table("common_member").' cm LEFT JOIN '.DB::table("common_member_field_home")." cmfh ON cmfh.uid=cm.uid WHERE cm.uid IN(".dimplode($fuids).")");*/
		$query = DB::query("SELECT cm.uid, cm.username, cmfh.recentnote FROM ".DB::table("common_member").' cm LEFT JOIN '.DB::table("common_member_field_home")." cmfh ON cmfh.uid=cm.uid WHERE cm.uid IN(".dimplode($fuids).")");
		
		while($value = DB::fetch($query)) {
			$value['isfriend'] = $value['uid']==$space['uid'] || $_G["home_friend_".$space['uid'].'_'.$value['uid']] ? 1 : 0;
			if(empty($list[$value['uid']])) $list[$value['uid']] = array();
			$list[$value['uid']] = array_merge($list[$value['uid']], $value);
		}
	//}
	
}

$navtitle = lang('core', 'title_friend_list');

$navtitle = lang('space', 'sb_friend', array('who' => $space['username']));
$metakeywords = lang('space', 'sb_friend', array('who' => $space['username']));
$metadescription = lang('space', 'sb_share', array('who' => $space['username']));

$a_actives = array($_GET['view'].$_GET['type'] => ' class="a"');

require_once libfile('function/post');
foreach ($list as $k => $v) {
	if ($v['username']) {
		$photo = avatar($v['uid'],'small');
	} else {
		$photo = '<img src="'.getsiteurl().STATICURL.'image/magic/hidden.gif" alt="匿名" />';
		//$list[$k]['username'] = $_G['setting']['anonymoustext'];
	}
	
	$list[$k]['photo'] = $photo;
	$list[$k]['recentnote'] = preg_replace("~src=\"(?!http:)(\w+)~i", 'src="'.getsiteurl().'\\1', $v['recentnote']);
	$list[$k]['recentnote'] = messagecutstr($v['recentnote'], 25);
		
	$v['lastvisit'] = DB::result_first("SELECT lastvisit FROM ".DB::table('common_member_status')." WHERE uid = '$v[uid]'");
	
	if ($_G['uid'] != $v['uid']) {
		$list[$k]['group'] = $groups[$v['gid']];
	}
	
	//echo $v['lastvisit']; exit;
	$list[$k]['ldateline'] = $v['lastvisit'];
	$list[$k]['lastvisit'] = dgmdate($v['lastvisit'], 'u');
	
	//$list[$k]['lastvisit'] = date('Y-m-d H:i:s', $v['lastvisit']);
	/*
	if ('online' == $_GET['view']) { 
		$list[$k]['lastvisit'] = dgmdate($ols[$v[uid]], 'H:i');
	} else if ($_GET['view'] == 'visitor' || $_GET['view'] == 'trace') {
		$list[$k]['lastvisit'] = dgmdate($v['dateline'], 'u');
	} else {*/
		/*if ($ols[$v[uid]]) {
			$list[$k]['lastvisit'] = dgmdate($ols[$v[uid]], 'H:i');
		} else {*/
			//$list[$k]['lastvisit'] = dgmdate($v['lastvisit'], 'u');
			//$list[$k]['lastvisit'] = $v['lastvisit'];
		//}
		//echo $list[$k]['lastvisit']; exit;
	//}
	
}

//排序
foreach($list as $row) {
	$sortaux[] = $row['ldateline'];
}
    
array_multisort($sortaux, SORT_DESC, $list);

/*MB add start*/
$jsonarr['zywy_total'] = $_G["zywy_total"];
$jsonarr['zywy_curpage'] = $_G["zywy_curpage"];
$jsonarr['zywy_totalpage'] = $_G["zywy_totalpage"];
 /*MB add end*/

	

$jsonarr['ols'] = $ols;
$jsonarr['list'] = $list;
$jsonarr['page'] = $multi;

jsonexit($jsonarr);

?>