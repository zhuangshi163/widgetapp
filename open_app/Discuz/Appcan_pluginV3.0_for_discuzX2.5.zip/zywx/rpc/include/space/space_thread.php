<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: space_thread.php 23183 2011-06-23 06:03:32Z zhengqingpeng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$minhot = $_G['setting']['feedhotmin']<1?3:$_G['setting']['feedhotmin'];
$page = empty($_GET['page'])?1:intval($_GET['page']);
if($page<1) $page=1;
$id = empty($_GET['id'])?0:intval($_GET['id']);
$opactives['thread'] = 'class="a"';

if(empty($_GET['view'])) $_GET['view'] = 'me';
$_GET['order'] = empty($_GET['order']) ? 'dateline' : $_GET['order'];

$allowviewuserthread = $_G['setting']['allowviewuserthread'];

$perpage = 10;
$start = ($page-1)*$perpage;
ckstart($start, $perpage);

$list = array();
$userlist = array();
$hiddennum = $count = $pricount = 0;

$gets = array(
	'mod' => 'space',
	'uid' => $space['uid'],
	'do' => 'thread',
	'view' => $_GET['view'],
	'type' => $_GET['type'],
	'order' => $_GET['order'],
	'fuid' => $_GET['fuid'],
	'searchkey' => $_GET['searchkey'],
	'from' => $_GET['from']
);
$theurl = 'home.php?'.url_implode($gets);
$multi = '';

require_once libfile('function/misc');
require_once libfile('function/forum');
loadcache(array('forums'));
$fids = $comma = '';
$wheresql = $_GET['view'] == 'me' || !$allowviewuserthread ? '1' : " t.fid IN(".$allowviewuserthread.")";
$wheresql .= $_GET['view'] != 'me' ? " AND t.displayorder>='0'" : '';
$f_index = '';
$ordersql = 't.dateline DESC';
$need_count = true;
$viewuserthread = false;
if($_GET['view'] == 'all') {
	$start = 0;
	$perpage = 100;
	$alltype = 'dateline';
	loadcache('space_thread');
	if($_GET['order'] == 'hot') {
		$wheresql .= " AND t.replies>='$minhot'";
		$alltype = 'hot';
	} else {
		$pruneperm = 0;
		if(($_G['adminid'] == 1 || $_G['adminid'] == 2)) {
			if(in_array($_G['uid'], explode(',', $_G['config']['admincp']['founder'])) || in_array($_G['username'], explode(',', $_G['config']['admincp']['founder']))) {
				$pruneperm = 1;
			} elseif(DB::result_first("SELECT ap.perm FROM ".DB::table('common_admincp_member')." am LEFT JOIN ".DB::table('common_admincp_perm')." ap ON ap.cpgroupid=am.cpgroupid WHERE am.uid='$_G[uid]' AND ap.perm='prune'")) {
				$pruneperm = 1;
			}
		}
		if(submitcheck('delthread') && $pruneperm) {
			require_once libfile('function/post');
			$moderate = $_GET['moderate'];
			$tidsadd = 'tid IN ('.dimplode($moderate).')';
			$tuidarray = $ruidarray = $fids = $posttablearr = array();
			$query = DB::query('SELECT tid, posttableid FROM '.DB::table('forum_thread').' WHERE '.$tidsadd);
			while($value = DB::fetch($query)) {
				$posttablearr[$value['posttableid'] ? $value['posttableid'] : 0][] = $value['tid'];
			}
			foreach($posttablearr as $posttableid => $ids) {
				$query = DB::query('SELECT fid, first, authorid FROM '.DB::table(getposttable($posttableid)).' WHERE tid IN ('.dimplode($ids).')');
				while($post = DB::fetch($query)) {
					if($post['first']) {
						$tuidarray[$post['fid']][] = $post['authorid'];
					} else {
						$ruidarray[$post['fid']][] = $post['authorid'];
					}
					$fids[$post['fid']] = $post['fid'];
				}
			}
			if($tuidarray) {
				foreach($tuidarray as $fid => $uids) {
					$_G['fid'] = $fid;
					updatepostcredits('-', $uids, 'post');
				}
			}
			if($ruidarray) {
				foreach($ruidarray as $fid => $uids) {
					$_G['fid'] = $fid;
					updatepostcredits('-', $uids, 'reply');
				}
			}

			require_once libfile('function/delete');
			deletethread($moderate);
			DB::query("DELETE FROM ".DB::table('forum_postcomment')." WHERE $tidsadd AND authorid='$space[uid]'");

			foreach($fids as $fid) {
				updateforumcount(intval($fid));
			}

			foreach($moderate as $tid) {
				my_thread_log('delete', array('tid' => $tid));
			}
			$_G['cache']['space_thread'][$alltype] = array();
			save_syscache('space_thread', $_G['cache']['space_thread']);

			//showmessage('thread_delete_succeed', 'home.php?mod=space&uid='.$space['uid'].'&do=thread&view=all');
			$msg = lang('message', 'thread_delete_succeed');
			jsonexit("{\"status\":\"0\",\"message\":\"$msg\"}");
		}
	}
	$orderactives = array($_GET['order'] => ' class="a"');

} elseif($_GET['view'] == 'me') {

	if($_GET['from'] == 'space') $diymode = 1;
	
	$viewtype = in_array($_GET['type'], array('reply', 'thread', 'postcomment')) ? $_GET['type'] : 'thread';
	$filter = in_array($_GET['filter'], array('recyclebin', 'ignored', 'save', 'aduit', 'close', 'common')) ? $_GET['filter'] : '';
	if($viewtype == 'thread') {
		$statusfield = 'displayorder';
		$wheresql .= " AND t.authorid = '$space[uid]'";
		$wheresql .= " AND t.displayorder>='0' AND t.closed='0'";
		/*if($filter == 'recyclebin') {
			$wheresql .= " AND t.displayorder='-1'";
		} elseif($filter == 'aduit') {
			$wheresql .= " AND t.displayorder='-2'";
		} elseif($filter == 'ignored') {
			$wheresql .= " AND t.displayorder='-3'";
		} elseif($filter == 'save') {
			$wheresql .= " AND t.displayorder='-4'";
		} elseif($filter == 'close') {
			$wheresql .= " AND t.closed='1'";
		} elseif($filter == 'common') {
			$wheresql .= " AND t.displayorder>='0' AND t.closed='0'";
		} elseif($space['uid'] != $_G['uid']) {
			if($allowviewuserthread === false && $_G['adminid'] != 1) {
				showmessage('ban_view_other_thead');
			}
			$viewuserthread = true;
			$viewfids = str_replace("'", '', $allowviewuserthread);
			if(!empty($viewfids)) {
				$viewfids = explode(',', $viewfids);
			}
		}*/
		$ordersql = 't.tid DESC';
	} elseif($viewtype == 'postcomment') {
		$posttable = getposttable();
		require_once libfile('function/post');
		$query = DB::query("SELECT c.*, p.authorid, p.tid, p.pid, p.fid, p.invisible, p.dateline, p.message, t.special, t.status, t.subject, t.digest,t.attachment, t.replies, t.views, t.lastposter, t.lastpost
			FROM ".DB::table('forum_postcomment')." c
			LEFT JOIN ".DB::table($posttable)." p ON p.pid = c.pid
			LEFT JOIN ".DB::table('forum_thread')." t ON t.tid = c.tid
			WHERE c.authorid = '$space[uid]' ORDER BY c.dateline DESC LIMIT $start, $perpage");

		$list = $fids = array();
		while($value = DB::fetch($query)) {
			$fids[] = $value['fid'];
			$value['comment'] = messagecutstr($value['comment'], 100);
			$list[] = procthread($value);
		}
		if($fids) {
			$fids = array_unique($fids);
			$query = DB::query("SELECT fid, name FROM ".DB::table('forum_forum')." WHERE fid IN (".dimplode($fids).")");
			while($forum = DB::fetch($query)) {
				$forums[$forum['fid']] = $forum['name'];
			}
		}

		$multi = simplepage(count($list), $perpage, $page, $theurl);
		$need_count = false;

	} else {
		$statusfield = 'invisible';
		$postsql = $threadsql = '';
		if($filter == 'recyclebin') {
			$postsql .= " AND p.invisible='-5'";
		} elseif($filter == 'aduit') {
			$postsql .= " AND p.invisible='-2'";
		} elseif($filter == 'save') {
			$postsql .= " AND p.invisible='-3' AND t.displayorder='-4'";
		} elseif($filter == 'ignored') {
			$postsql .= " AND p.invisible='-3' AND t.displayorder!='-4'";
		} elseif($filter == 'close') {
			$threadsql .= " AND t.closed='1'";
		} elseif($filter == 'common') {
			$postsql .= " AND p.invisible='0'";
			$threadsql .= " AND t.displayorder>='0' AND t.closed='0'";
		} elseif($space['uid'] != $_G['uid']) {
			if($allowviewuserthread === false && $_G['adminid'] != 1) {
				//showmessage('ban_view_other_thead');
				$msg = lang('message', 'ban_view_other_thead');
				jsonexit("{\"status\":\"0\",\"message\":\"$msg\"}");
			}
			$threadsql .= empty($allowviewuserthread) ? '' : " AND t.fid IN($allowviewuserthread) ";
		}
		$postsql .= " AND p.first='0'";
		$posttable = getposttable();

		require_once libfile('function/post');
		$query = DB::query("SELECT p.authorid, p.tid, p.pid, p.fid, p.invisible, p.dateline, p.message, t.special, t.status, t.subject, t.digest,t.attachment, t.replies, t.views, t.lastposter, t.lastpost, t.displayorder FROM ".DB::table($posttable)." p
		INNER JOIN ".DB::table('forum_thread')." t ON t.tid=p.tid $threadsql
		WHERE p.authorid='$space[uid]' $postsql ORDER BY p.dateline DESC LIMIT $start,$perpage");

		$list = $fids = array();
		while($value = DB::fetch($query)) {
			$fids[] = $value['fid'];
			$value['message'] = !getstatus($value['status'], 2) || $value['authorid'] == $_G['uid'] ? messagecutstr($value['message'], 100) : '';
			$list[] = procthread($value) ;
			$tids[$value['tid']] = $value['tid'];
		}
		if($fids) {
			$fids = array_unique($fids);
			$query = DB::query("SELECT fid, name, status FROM ".DB::table('forum_forum')." WHERE fid IN (".dimplode($fids).")");
			while($forum = DB::fetch($query)) {
				if(!$_G['setting']['groupstatus'] && $forum['status'] == 3) {
				} else {
					$forums[$forum['fid']] = $forum['name'];
				}
			}
			foreach($list as $key => $val) {
				if(!$forums[$val['fid']]) {
					unset($list[$key]);
				}
			}
		}

		$multi = simplepage(count($list), $perpage, $page, $theurl);

		$need_count = false;
	}
	$orderactives = array($viewtype => ' class="a"');

} else {

	space_merge($space, 'field_home');

	if($space['feedfriend']) {

		$fuid_actives = array();

		require_once libfile('function/friend');
		$fuid = intval($_GET['fuid']);
		if($fuid && friend_check($fuid, $space['uid'])) {
			$wheresql .= " AND t.authorid='$fuid'";
			$fuid_actives = array($fuid=>' selected');
		} else {
			$wheresql .= " AND t.authorid IN ($space[feedfriend])";
			$theurl = "home.php?mod=space&uid=$space[uid]&do=$do&view=we";
		}

		$query = DB::query("SELECT * FROM ".DB::table('home_friend')." WHERE uid='$_G[uid]' ORDER BY num DESC LIMIT 0,100");
		while ($value = DB::fetch($query)) {
			$userlist[] = $value;
		}
	} else {
		$need_count = false;
	}
}

$actives = array($_GET['view'] =>' class="a"');

if($need_count) {

	if($searchkey = stripsearchkey($_GET['searchkey'])) {
		$wheresql .= " AND t.subject LIKE '%$searchkey%'";
		$searchkey = dhtmlspecialchars($searchkey);
	}

	$havecache = false;
	if($_GET['view'] == 'all') {

		$cachetime = $_GET['order'] == 'hot' ? 43200 : 3000;
		if(!empty($_G['cache']['space_thread'][$alltype]) && is_array($_G['cache']['space_thread'][$alltype])) {
			$threadarr = $_G['cache']['space_thread'][$alltype];
			if(!empty($threadarr['dateline']) && $threadarr['dateline'] > $_G['timestamp'] - $cachetime) {
				$list = $threadarr['data'];
				$forums = $threadarr['forums'];
				$hiddennum = $threadarr['hiddennum'];
				$havecache = true;
			}
		}
	}
	if(!$havecache) {
		if($viewtype == "thread"){
			$wheresql2 = 'AND p.first=1 ';
		}
								
		$query = DB::query("SELECT t.tid, t.fid, t.subject, t.author, t.authorid, t.views, 
							t.replies, t.lastpost, t.digest, t.closed, t.attachment, 
							p.message, fp.latitude, f.name AS forumname FROM ".DB::table('forum_thread')." AS t 
							LEFT JOIN ".DB::table('forum_post')." AS p
							ON t.tid=p.tid $wheresql2
							LEFT JOIN ".DB::table('forum_forum')." AS f
							ON t.fid=f.fid 
							LEFT JOIN ".DB::table('zywx_forum_postfield')." AS fp
							ON p.pid=fp.pid 
							WHERE $wheresql ORDER BY $ordersql LIMIT $start,$perpage");

		$fids = $forums = array();
		while($value = DB::fetch($query)) {
			if(empty($value['author']) && $value['authorid'] != $_G['uid']) {
				$hiddennum++;
				continue;
			}
			if($viewuserthread && $value['authorid'] != $_G['uid']) {
				if(($_G['adminid'] != 1 && !empty($viewfids) && !in_array($value['fid'], $viewfids)) || $value['displayorder'] < 0) {
					$hiddennum++;
					continue;
				}
			}
			$value['message'] = cutstr($value['message'], 200);

			$fids[] = $value['fid'];
			$value['lastpost'] = dgmdate($value['lastpost'], 'u');
			//$list[] = procthread($value);
			$list[] = $value;
		}

		if($fids) {
			$fids = array_unique($fids);
			$query = DB::query("SELECT fid, name, status FROM ".DB::table('forum_forum')." WHERE fid IN (".dimplode($fids).")");
			while($forum = DB::fetch($query)) {
				if(!$_G['setting']['groupstatus'] && $forum['status'] == 3) {
				} else {
					$forums[$forum['fid']] = $forum['name'];
				}
			}
		}
		
		/*foreach($list as $key => $val) {
			if(!$forums[$val['fid']] || $val['closed'] > 1) {
				unset($list[$key]);
				$hiddennum++;
			}
		}*/
		if($_GET['view'] == 'all') {
			$_G['cache']['space_thread'][$alltype] = array(
				'dateline' => $_G['timestamp'],
				'hiddennum' => $hiddennum,
				'forums' => $forums,
				'data' => $list
			);
			save_syscache('space_thread', $_G['cache']['space_thread']);
		}
	}

	if($_GET['view'] != 'all') {
		//$multi = simplepage(count($list)+$hiddennum, $perpage, $page, $theurl);
	}
}

dsetcookie('home_diymode', $diymode);

if($_G['uid']) {
	$_GET['view'] = !$_GET['view'] ? 'we' : $_GET['view'];
	$navtitle = lang('core', 'title_'.$_GET['view'].'_thread');
} else {
	$navtitle = lang('core', 'title_thread');
}

if($space['username']) {
	$navtitle = lang('space', 'sb_thread', array('who' => $space['username']));
}
$metakeywords = $navtitle;
$metadescription = $navtitle;

require_once libfile('function/post');

foreach($list as $key => $value) {
    $list[$key]['subject'] = cutstr($value['subject'], 100);
    $list[$key]['message'] = messagecutstr($value['message'], 100);
	$list[$key]['lastpost'] = strip_tags($value['lastpost']);
}

if (!empty ( $list )){
	if($viewtype == "thread"){
		$total_list = count($list) + $hiddennum;
	}else{
		$total_list = count($list);
	}
    if($total_list < $perpage || $page == 5){
        $jsonarr['page'] = 0;
    }else{
        $jsonarr['page'] = $page + 1;
    }
}
	
if($viewtype == "thread"){
	$num_total = DB::getOne("SELECT count(t.tid) FROM ".DB::table('forum_thread')." t
				LEFT JOIN ".DB::table('forum_post')." AS p ON t.tid = p.tid WHERE p.first = 1 AND t.displayorder>='0' AND t.closed='0' AND t.authorid = '$space[uid]'");
	$jsonarr['total'] = $num_total;

}else if($viewtype == "reply"){
	$num_total = DB::getOne("SELECT count(p.tid) FROM ".DB::table($posttable)." p INNER JOIN 
	".DB::table('forum_thread')." t ON t.tid=p.tid $threadsql WHERE p.authorid='$space[uid]' $postsql ");
}
	
if($num_total > $perpage) {
	$pages = @ceil($num_total / $perpage);
		
	/*MB add start*/
	$_G["zywy_totalpage"] = $pages;
 	/*MB add end*/
}
	
/*MB add start*/
$jsonarr['zywy_curpage'] = $_G["gp_page"];
$jsonarr['zywy_totalpage'] = $_G["zywy_totalpage"];
/*MB add end*/
$jsonarr['hiddennum'] = $hiddennum;
$jsonarr['list'] = $list;
$jsonarr['viewtype'] = $viewtype;
$jsonarr['forums'] = $forums;

jsonexit($jsonarr);